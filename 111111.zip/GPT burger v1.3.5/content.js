// GPT Burger v1.3.5
console.log("🍔 GPT Burger content script loaded. Version 1.3.5");

console.log(
    "%c 🍔 GPT BURGER SCRIPT ATTEMPTING TO LOAD (v1.3.5) 🍔 %c If you see this, the new script is loading. If not, the extension needs a manual reload from chrome://extensions.",
    "background: #ffcc00; color: #333; font-size: 14px; font-weight: bold; padding: 5px;",
    "background: #f0f0f0; color: #333; padding: 5px;"
);

// 🔧 用户设置
const USER_SETTINGS = {
    enableHoverExpand: true,  // 是否启用悬停展开功能
    hoverDelay: 0            // 悬停延迟时间（毫秒）- 改为立即显示
};

// 🔵 获取当前页面的对话 ID
function getCurrentChatId() {
  // 🛠️ ChatGPT 每个聊天地址都有 /c/xxx 格式
  const match = window.location.pathname.match(/\/c\/([\w-]+)/);
  return match ? match[1] : "default"; // 💡 没找到时用 fallback
}

// 🔵 所有书签数据储存在这个变量中
let lastBookmarkId = null;
let allBookmarks = {}; // 🛠️ 结构：{ chatId1: [书签数组], chatId2: [...] }
let currentChatId = getCurrentChatId(); // 🔵 当前对话的唯一标识（从网址中提取）
let bookmarkIdCounter = 0; // 🔵 自动编号书签锚点
let isManageMode = false; // 🔵 管理模式状态
let selectedBookmarks = new Set(); // 🔵 选中的书签集合
let selectedGroups = new Set(); // 🔵 选中的分组集合
let tempBookmark = null; // 🔵 临时书签变量

// 悬停展开相关变量
let hoverTimeout = null;
let isHoveringButton = false;
let isHoveringList = false;

// 预设的 emoji 分组
const DEFAULT_EMOJI_GROUPS = ['🍅', '🥬', '🧀', '🥒', '🥩'];

// 🔵 从 localStorage 读取书签数据
function loadBookmarksFromStorage() {
  const saved = localStorage.getItem("gptBookmarks");
  if (saved) {
        allBookmarks = JSON.parse(saved);
        
        // 确保每个对话都有完整的数据结构
        for (let chatId in allBookmarks) {
            if (!allBookmarks[chatId].bookmarks) {
                allBookmarks[chatId].bookmarks = [];
            }
            
            // 确保有 groupOrder 且包含所有默认分组
            if (!allBookmarks[chatId].groupOrder) {
                allBookmarks[chatId].groupOrder = ['', ...DEFAULT_EMOJI_GROUPS];
            } else {
                // 确保默认分组在最前面
                if (!allBookmarks[chatId].groupOrder.includes('')) {
                    allBookmarks[chatId].groupOrder.unshift('');
                }
                // 确保包含所有预设 emoji 分组
                DEFAULT_EMOJI_GROUPS.forEach(emoji => {
                    if (!allBookmarks[chatId].groupOrder.includes(emoji)) {
                    const defaultIndex = allBookmarks[chatId].groupOrder.indexOf('');
                        allBookmarks[chatId].groupOrder.splice(defaultIndex + 1, 0, emoji);
                }
                });
            }
        }
        
        console.log("📚 从 localStorage 加载书签数据：", {
            chatIds: Object.keys(allBookmarks),
            currentChatData: allBookmarks[currentChatId],
            allData: allBookmarks
        });
        return true;
    }
    return false;
}

// 🔵 获取当前这个对话的书签数组
function getCurrentChatBookmarks() {
    const chatData = allBookmarks[currentChatId];
    if (chatData && Array.isArray(chatData.bookmarks)) {
      return chatData.bookmarks;
    }
    return [];
  }
  
// 🔵 把当前所有书签保存到 localStorage
function saveBookmarksToStorage() {
    localStorage.setItem("gptBookmarks", JSON.stringify(allBookmarks));
    console.log("💾 已写入 localStorage.gptBookmarks：", allBookmarks);
}

// 🔵 插件入口：页面加载完成后执行
function initPlugin() {
    console.log("🚀 [Debug] initPlugin: Starting initialization...");
    
    // Add visual debug indicator
    const debugIndicator = document.createElement('div');
    debugIndicator.id = 'gpt-burger-debug-indicator';
    debugIndicator.textContent = 'GPT Burger v1.3.5 LOADED';
    document.body.appendChild(debugIndicator);
    console.log(" VISUAL DEBUG INDICATOR ADDED ");
    
    // 加载保存的书签数据
    loadBookmarksFromStorage();
    
    // 创建样式和UI
    createStyles();
    createBookmarkUI();
    
    // 创建快速操作弹窗
    createQuickActionPopup();
    
    // 等待页面加载完成后渲染书签
    waitForArticlesAndRender();
    
    // 监听主题变化
    observeThemeChanges();
    
    console.log("✅ [Debug] initPlugin: Initialization complete.");
}

// 监听主题变化
function observeThemeChanges() {
    const observer = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
            if (mutation.attributeName === 'class' && mutation.target === document.documentElement) {
                console.log("👀 检测到 HTML 类变化，可能是主题切换");
                handleThemeChange();
            }
        });
    });

    observer.observe(document.documentElement, {
        attributes: true,
        attributeFilter: ['class']
    });

    console.log("🎭 主题监听器已启动");
}

// ✅ 等待页面上的 article 加载完成后再渲染书签
function waitForArticlesAndRender() {
    console.log("👀 等待页面加载...");
    
    // 确保书签列表容器存在
    if (!document.getElementById('gpt-bookmark-list')) {
        console.log("⚠️ 书签列表容器不存在，重新创建");
        createBookmarkUI();
    }
    
    const articles = document.querySelectorAll("article");
    if (articles.length > 0) {
        console.log("✅ 页面已加载，开始渲染书签");
        renderBookmarkList();
        return;
    }

    console.log("⏳ 页面未加载完成，开始监听...");
    const observer = new MutationObserver(() => {
        const articles = document.querySelectorAll("article");
        if (articles.length > 0) {
            observer.disconnect(); // 🔚 停止监听
            console.log("✅ 检测到页面加载完成，开始渲染书签");
            
            // 再次确保书签列表容器存在
            if (!document.getElementById('gpt-bookmark-list')) {
                console.log("⚠️ 书签列表容器不存在，重新创建");
                createBookmarkUI();
            }
            
            renderBookmarkList();
        }
    });

    // 👂监听页面变化，直到 article 元素出现
    observer.observe(document.body, { childList: true, subtree: true });
}

// 创建基础UI
function createBookmarkUI() {
    console.log("🎨 [Debug] createBookmarkUI: Starting UI creation...");
    
    // 检查是否已存在切换按钮，如果存在则移除旧的
    const existingToggle = document.getElementById('gpt-bookmark-toggle');
    if (existingToggle) {
        console.log("🗑️ [Debug] createBookmarkUI: Removing existing toggle button.");
        existingToggle.remove();
    }
    
    // 检查是否已存在书签列表，如果存在则移除旧的
    const existingList = document.getElementById('gpt-bookmark-list');
    if (existingList) {
        console.log("🗑️ [Debug] createBookmarkUI: Removing existing bookmark list.");
        existingList.remove();
    }
    
    // 创建折叠切换按钮
    const toggleBtn = document.createElement("button");
    toggleBtn.className = "gpt-bookmark-toggle";
    toggleBtn.id = "gpt-bookmark-toggle";
    toggleBtn.innerHTML = "📑";
    toggleBtn.title = "展开书签";
    
    // 创建主容器
    const list = document.createElement("div");
    list.className = "gpt-bookmark-list collapsed";
    list.id = "gpt-bookmark-list";
    
    // 添加基础内容
    list.innerHTML = `
        <div class="bookmark-content">
            <div class="group-header">
                <span style="flex: 1;">📑 ${i18n('myBookmarks')}</span>
                    <button class="manage-btn" style="
            padding: 4px 8px;
            border-radius: 4px;
            border: 1px solid #ccc;
            background: #f0f0f0;
            cursor: pointer;
            transition: all 0.2s;
        ">${i18n('selectMode')}</button>
            </div>
            <div id="bookmark-list-items"></div>
        </div>
    `;
    
    // 直接将UI元素添加到body中
    document.body.appendChild(toggleBtn);
    document.body.appendChild(list);
    
    console.log("✅ [Debug] createBookmarkUI: UI elements (toggle, list) appended directly to body.");
    
    // 悬停展开相关变量已在全局定义
    
    // 添加悬停展开功能
    toggleBtn.addEventListener('mouseenter', () => {
        if (!USER_SETTINGS.enableHoverExpand) return; // 检查设置开关
        
        isHoveringButton = true;
        
        // 立即展开
        if (list.classList.contains('collapsed')) {
            list.classList.remove('collapsed');
            toggleBtn.innerHTML = "📖";
            toggleBtn.title = "收起书签";
            console.log("🖱️ 悬停展开书签列表");
        }
    });
    
    toggleBtn.addEventListener('mouseleave', () => {
        if (!USER_SETTINGS.enableHoverExpand) return; // 检查设置开关
        
        isHoveringButton = false;
        
        // 延迟检查是否需要收起
        setTimeout(() => {
            if (!isHoveringButton && !isHoveringList) {
                if (!list.hasAttribute('data-keep-open') && !list.classList.contains('collapsed')) {
                    list.classList.add('collapsed');
                    toggleBtn.innerHTML = "📑";
                    toggleBtn.title = "展开书签";
                    console.log("🖱️ 悬停离开，收起书签列表");
                }
            }
        }, 200);
    });
    
    // 书签列表的悬停状态
    list.addEventListener('mouseenter', () => {
        if (!USER_SETTINGS.enableHoverExpand) return;
        isHoveringList = true;
    });
    
    list.addEventListener('mouseleave', () => {
        if (!USER_SETTINGS.enableHoverExpand) return;
        
        isHoveringList = false;
        // 延迟检查是否需要收起
        setTimeout(() => {
            if (!isHoveringButton && !isHoveringList) {
                if (!list.hasAttribute('data-keep-open') && !list.classList.contains('collapsed')) {
                    list.classList.add('collapsed');
                    toggleBtn.innerHTML = "📑";
                    toggleBtn.title = "展开书签";
                    console.log("🖱️ 离开书签列表，自动收起");
                }
            }
        }, 200);
    });
    
    // 添加管理按钮事件
    const manageBtn = list.querySelector('.manage-btn');
    if (manageBtn) {
        manageBtn.onclick = () => {
            isManageMode = !isManageMode;
            selectedBookmarks.clear();
            selectedGroups.clear();
            manageBtn.textContent = isManageMode ? i18n('doneMode') : i18n('selectMode');
            renderBookmarkList();
        };
    }
    
    // 立即渲染一次
    renderBookmarkList();
}

// 添加深色模式检测和切换
function handleThemeChange() {
    console.log("🌓 检测到主题变化");
    const isDarkMode = document.documentElement.classList.contains('dark');
    console.log(`🎨 当前主题模式: ${isDarkMode ? '深色' : '浅色'}`);
    
    // 更新切换按钮样式
    const toggleBtn = document.getElementById('gpt-bookmark-toggle');
    if (toggleBtn) {
        toggleBtn.style.background = isDarkMode ? '#202123' : 'white';
        toggleBtn.style.color = isDarkMode ? '#fff' : '#000';
        toggleBtn.style.borderColor = isDarkMode ? '#4a4b4d' : '#ccc';
    }
    
    // 更新快速操作弹窗样式
    const popup = document.getElementById('quick-action-popup');
    if (popup) {
        popup.style.background = isDarkMode ? '#202123' : '#ffffff';
        popup.style.color = isDarkMode ? '#fff' : '#000';
        popup.style.borderColor = isDarkMode ? '#4a4b4d' : '#e5e5e5';
        
        // 更新所有输入框样式
        popup.querySelectorAll('input').forEach(input => {
            input.style.background = isDarkMode ? '#343541' : '#ffffff';
            input.style.color = isDarkMode ? '#fff' : '#000';
            input.style.borderColor = isDarkMode ? '#4a4b4d' : '#ccc';
        });
        
        // 更新新分组按钮样式
        const newGroupBtn = popup.querySelector('.new-group-btn');
        if (newGroupBtn) {
            newGroupBtn.style.borderColor = isDarkMode ? '#4a4b4d' : '#ccc';
            newGroupBtn.style.color = isDarkMode ? '#fff' : '#000';
        }
        
        // 更新取消按钮样式
        const cancelBtn = popup.querySelector('.cancel-new-group');
        if (cancelBtn) {
            cancelBtn.style.background = isDarkMode ? '#343541' : '#f0f0f0';
            cancelBtn.style.color = isDarkMode ? '#fff' : '#666';
        }
        
        // 更新新分组表单样式
        const newGroupForm = popup.querySelector('.new-group-form');
        if (newGroupForm) {
            const newGroupInput = newGroupForm.querySelector('.new-group-input');
            if (newGroupInput) {
                newGroupInput.style.background = isDarkMode ? '#343541' : '#ffffff';
                newGroupInput.style.color = isDarkMode ? '#fff' : '#000';
                newGroupInput.style.borderColor = isDarkMode ? '#4a4b4d' : '#ccc';
            }
        }
    }
    
    // 更新移动到分组弹窗样式
    const movePopup = document.querySelector('.move-to-group-popup');
    if (movePopup) {
        movePopup.style.background = isDarkMode ? '#202123' : '#ffffff';
        movePopup.style.color = isDarkMode ? '#fff' : '#000';
        movePopup.style.borderColor = isDarkMode ? '#4a4b4d' : '#ccc';
    }
}

// 简化编辑功能
function makeEditable(titleElement, bookmark) {
    console.log('🖊️ 开始编辑模式', bookmark);
    
    // 创建输入框
    const editInput = document.createElement('input');
    editInput.className = 'bookmark-edit-input';
    editInput.value = bookmark.summary;
    editInput.style.width = '100%';
    editInput.style.padding = '4px 8px';
    editInput.style.border = '1px solid #ccc';
    editInput.style.borderRadius = '4px';
    
    // 替换原标题元素
    titleElement.parentNode.replaceChild(editInput, titleElement);
    editInput.focus();
    editInput.select();
    
    // 处理回车保存
    editInput.onkeydown = (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            editInput.blur();
        }
        if (e.key === 'Escape') {
            editInput.value = bookmark.summary;
            editInput.blur();
        }
    };
    
    // 处理失焦保存
    editInput.onblur = () => {
        const newTitle = editInput.value.trim();
        if (newTitle && newTitle !== bookmark.summary) {
            bookmark.summary = newTitle;
            saveBookmarksToStorage();
        }
        renderBookmarkList();
    };
}

// 简化跳转功能
function jumpToBookmark(bookmark) {
    console.log('🎯 准备跳转到书签位置', bookmark);
    
    // 🆕 显示新的容器信息（如果存在）
    if (bookmark.containerInfo) {
        console.log('📊 [跳转分析] 发现增强的容器信息:', bookmark.containerInfo);
        console.log('📊 [跳转分析] 容器类型:', bookmark.containerInfo.type);
        if (bookmark.containerInfo.container) {
            console.log('📊 [跳转分析] 容器详情:', {
                标签: bookmark.containerInfo.container.tagName,
                类名: bookmark.containerInfo.container.className,
                绝对位置: bookmark.containerInfo.container.offsetTop,
                相对位置: bookmark.containerInfo.container.relativeToArticle
            });
        }
    } else {
        console.log('📊 [跳转分析] 使用传统定位信息 (offset:', bookmark.offset, ')');
    }
    
    if (!bookmark.offset) {
        console.warn('❌ 书签没有保存位置信息');
        alert('书签没有保存跳转位置！');
        return;
    }
    
    const scrollContainer = document.querySelector('main div[class*="overflow-y-auto"]');
    if (!scrollContainer) {
        console.warn('❌ 未找到滚动容器');
        alert('未找到滚动容器！');
        return;
    }
    
    // 🆕 当前仍使用原有逻辑，但打印对比信息
    const originalTarget = bookmark.offset - window.innerHeight / 2;
    console.log('📊 [跳转分析] 原有跳转目标位置:', originalTarget);
    console.log('📊 [跳转分析] 窗口高度:', window.innerHeight);
    console.log('📊 [跳转分析] 原始offset:', bookmark.offset);
    
    // 🆕 如果有新的容器信息，计算新的目标位置但不使用
    if (bookmark.containerInfo && bookmark.containerInfo.container) {
        // 🔍 重新查找容器元素，而不是使用保存的引用
        const currentArticle = document.querySelector(`article[data-testid="${bookmark.articleId}"]`);
        if (!currentArticle) {
            console.warn('❌ [调试] 无法找到当前Article元素');
            return;
        }
        
        console.log('🔍 [调试] 当前Article信息:', {
            offsetTop: currentArticle.offsetTop,
            isConnected: currentArticle.isConnected
        });
        
        // 🔍 根据保存的信息重新查找容器元素
        const containerInfo = bookmark.containerInfo.container;
        let foundContainer = null;
        
        console.log('🔍 [调试] 保存的容器信息:', containerInfo);
        
        // 尝试通过ID查找
        if (containerInfo.attributes && containerInfo.attributes.id) {
            foundContainer = document.getElementById(containerInfo.attributes.id);
            console.log('🔍 [调试] 通过ID查找容器:', foundContainer ? '成功' : '失败');
        }
        
        // 尝试通过data-testid查找
        if (!foundContainer && containerInfo.attributes && containerInfo.attributes['data-testid']) {
            foundContainer = document.querySelector(`[data-testid="${containerInfo.attributes['data-testid']}"]`);
            console.log('🔍 [调试] 通过data-testid查找容器:', foundContainer ? '成功' : '失败');
        }
        
        // 尝试通过文本内容匹配查找
        if (!foundContainer && (containerInfo.selectedText || containerInfo.textContent)) {
            const allElements = currentArticle.querySelectorAll(containerInfo.tagName);
            console.log(`🔍 [调试] 在article中找到 ${allElements.length} 个 ${containerInfo.tagName} 元素`);
            
            // 优先使用用户选中的文本进行匹配
            const targetText = containerInfo.selectedText || containerInfo.textContent || '';
            console.log(`🔍 [调试] 目标文本: "${targetText}"`);
            
            for (const element of allElements) {
                const elementText = element.textContent ? element.textContent.substring(0, 100).trim() : '';
                console.log(`🔍 [调试] 比较文本: "${elementText}" vs "${targetText}"`);
                
                // 🆕 检查容器文本是否包含用户选中的文本
                if (elementText && targetText && elementText.includes(targetText)) {
                    foundContainer = element;
                    console.log('🔍 [调试] 通过文本包含匹配找到容器');
                    break;
                }
                
                // 备用：精确匹配
                if (elementText && elementText === targetText) {
                    foundContainer = element;
                    console.log('🔍 [调试] 通过文本精确匹配找到容器');
                    break;
                }
            }
        }
        
        // 🆕 尝试通过className匹配查找
        if (!foundContainer && containerInfo.className) {
            const elementsWithClass = currentArticle.querySelectorAll(`${containerInfo.tagName}.${containerInfo.className.split(' ')[0]}`);
            console.log(`🔍 [调试] 通过类名查找到 ${elementsWithClass.length} 个元素`);
            
            const targetText = containerInfo.selectedText || containerInfo.textContent || '';
            
            for (const element of elementsWithClass) {
                // 使用文本内容的前50个字符进行二次验证
                const elementText = element.textContent ? element.textContent.substring(0, 50).trim() : '';
                const savedText = targetText.substring(0, 50);
                console.log(`🔍 [调试] 类名匹配 + 文本验证: "${elementText}" vs "${savedText}"`);
                
                if (elementText && savedText && elementText.includes(savedText)) {
                    foundContainer = element;
                    console.log('🔍 [调试] 通过className + 文本验证找到容器');
                    break;
                }
            }
        }
        
        // 🆕 尝试通过相对位置查找（最后的容错方案）
        if (!foundContainer && containerInfo.relativeToArticle !== undefined) {
            const allElements = currentArticle.querySelectorAll(containerInfo.tagName);
            console.log(`🔍 [调试] 尝试通过相对位置查找，目标位置: ${containerInfo.relativeToArticle}`);
            
            const targetText = containerInfo.selectedText || containerInfo.textContent || '';
            
            for (const element of allElements) {
                const currentRelative = element.offsetTop - currentArticle.offsetTop;
                const positionDiff = Math.abs(currentRelative - containerInfo.relativeToArticle);
                console.log(`🔍 [调试] 元素相对位置: ${currentRelative}, 差异: ${positionDiff}px`);
                
                // 如果位置差异在合理范围内（50px），且文本相似
                if (positionDiff < 50) {
                    const elementText = element.textContent ? element.textContent.substring(0, 30).trim() : '';
                    const savedText = targetText.substring(0, 30);
                    
                    if (elementText && savedText && elementText.includes(savedText.substring(0, 15))) {
                        foundContainer = element;
                        console.log('🔍 [调试] 通过相对位置 + 部分文本匹配找到容器');
                        break;
                    }
                }
            }
        }
        
        // 🆕 特殊处理：表格单元格定位
        if (!foundContainer && containerInfo.tableInfo && 
            (containerInfo.tagName === 'TD' || containerInfo.tagName === 'TH')) {
            
            console.log('📊 [表格定位] 尝试通过行列位置查找单元格');
            const { rowIndex, colIndex } = containerInfo.tableInfo;
            
            // 查找当前article中的所有表格
            const tables = currentArticle.querySelectorAll('table');
            console.log(`📊 [表格定位] 找到 ${tables.length} 个表格`);
            
            for (const table of tables) {
                const rows = table.querySelectorAll('tr');
                if (rows.length > rowIndex) {
                    const targetRow = rows[rowIndex];
                    const cells = targetRow.querySelectorAll('td, th');
                    
                    if (cells.length > colIndex) {
                        const targetCell = cells[colIndex];
                        const cellText = targetCell.textContent.trim();
                        const savedText = containerInfo.selectedText;
                        
                        console.log(`📊 [表格定位] 检查单元格[${rowIndex}][${colIndex}]: "${cellText}"`);
                        console.log(`📊 [表格定位] 目标文本: "${savedText}"`);
                        
                        // 检查单元格是否包含目标文本
                        if (cellText.includes(savedText)) {
                            foundContainer = targetCell;
                            console.log('✅ [表格定位] 通过行列位置成功找到单元格');
                            break;
                        }
                    }
                }
            }
        }
        
        if (foundContainer) {
            console.log('🔍 [调试] 重新找到的容器元素详细信息:', {
                tagName: foundContainer.tagName,
                className: foundContainer.className,
                offsetTop: foundContainer.offsetTop,
                offsetParent: foundContainer.offsetParent?.tagName,
                isConnected: foundContainer.isConnected,
                在文档中: document.contains(foundContainer)
            });
            
            // 重新计算相对位置
            const recalculatedRelative = foundContainer.offsetTop - currentArticle.offsetTop;
            console.log('🔍 [调试] 重新计算的相对位置:', recalculatedRelative);
            console.log('🔍 [调试] 保存的相对位置:', containerInfo.relativeToArticle);
            
            const newTarget = foundContainer.offsetTop - window.innerHeight / 3;
            console.log('📊 [跳转分析] 新方法计算的目标位置:', newTarget);
            console.log('📊 [跳转分析] 位置差异:', Math.abs(newTarget - originalTarget), 'px');
            
            // 🔍 异常数值检测
            if (Math.abs(newTarget - originalTarget) > 100000) {
                console.error('🚨 [调试] 检测到异常的位置差异！可能的原因:');
                console.error('  - 容器元素的offsetTop异常:', foundContainer.offsetTop);
                console.error('  - 元素可能不在正确的布局上下文中');
                console.error('  - DOM结构发生了变化');
            }
        } else {
            console.warn('❌ [调试] 无法重新找到容器元素，将使用原有逻辑');
            console.log('📊 [统计] 查找尝试总结:', {
                '通过ID查找': containerInfo.attributes?.id ? '尝试' : '跳过',
                '通过data-testid查找': containerInfo.attributes?.['data-testid'] ? '尝试' : '跳过', 
                '通过文本匹配查找': containerInfo.textContent ? '尝试' : '跳过',
                '通过className查找': containerInfo.className ? '尝试' : '跳过',
                '通过相对位置查找': containerInfo.relativeToArticle !== undefined ? '尝试' : '跳过',
                '保存的容器类型': containerInfo.tagName,
                '保存的文本长度': containerInfo.textContent?.length || 0,
                '当前article中同类型元素数量': currentArticle.querySelectorAll(containerInfo.tagName).length
            });
        }
    }
    
    scrollContainer.scrollTo({
        top: originalTarget,
        behavior: 'smooth'
    });
    
    console.log('✅ 跳转完成 (使用原有逻辑)');
}

// 显示移动到分组的弹窗
function showMoveToGroupPopup(selectedIds) {
    console.log('显示移动到分组弹窗，选中的书签：', selectedIds);
    
    // 获取现有的所有分组
    const existingGroups = new Set();
    const chatData = allBookmarks[currentChatId];
    if (chatData && Array.isArray(chatData.bookmarks)) {
        chatData.bookmarks.forEach(bm => {
            if (bm.group && !DEFAULT_EMOJI_GROUPS.includes(bm.group)) {
                existingGroups.add(bm.group);
            }
        });
    }
    console.log('现有分组：', existingGroups);
    
    // 创建弹窗
    const popup = document.createElement('div');
    popup.className = 'move-to-group-popup';
    const isDarkMode = document.documentElement.classList.contains('dark');
    popup.style.cssText = `
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: ${isDarkMode ? '#202123' : 'white'};
        color: ${isDarkMode ? '#fff' : '#000'};
        padding: 16px;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        z-index: 10000;
        min-width: 200px;
        border: 1px solid ${isDarkMode ? '#4a4b4d' : '#ccc'};
    `;
    
    // 创建弹窗内容
    popup.innerHTML = `
        <div style="margin-bottom: 8px; font-weight: bold;">${i18n('selectTargetGroup')}</div>
        <div class="group-list" style="margin-bottom: 12px;">
            <div class="group-option" data-group="" style="padding: 4px 8px; cursor: pointer; border-radius: 4px;">
                📦 ${i18n('defaultGroup')}
            </div>
            ${DEFAULT_EMOJI_GROUPS.map(emoji => `
                <div class="group-option" data-group="${emoji}" style="padding: 4px 8px; cursor: pointer; border-radius: 4px;">
                    ${emoji}
                </div>
            `).join('')}
            ${Array.from(existingGroups).map(group => `
                <div class="group-option" data-group="${group}" style="padding: 4px 8px; cursor: pointer; border-radius: 4px;">
                    ${group}
                </div>
            `).join('')}
        </div>
        <div style="margin-bottom: 8px;">
            <input type="text" placeholder="${i18n('enterGroupName')}" class="new-group-input" style="
                width: 100%;
                padding: 4px 8px;
                border: 1px solid ${isDarkMode ? '#4a4b4d' : '#ccc'};
                border-radius: 4px;
                background: ${isDarkMode ? '#343541' : 'white'};
                color: ${isDarkMode ? '#fff' : '#000'};
            ">
        </div>
        <div style="text-align: right;">
            <button class="cancel-move" style="
                padding: 4px 8px;
                margin-right: 8px;
                border-radius: 4px;
                background: ${isDarkMode ? '#343541' : '#f0f0f0'};
                color: ${isDarkMode ? '#fff' : '#666'};
                border: none;
                cursor: pointer;
            ">取消</button>
        </div>
    `;
    
    document.body.appendChild(popup);
    
    // 点击分组选项
    popup.querySelectorAll('.group-option').forEach(option => {
        option.addEventListener('click', () => {
            const groupName = option.dataset.group;
            moveBookmarksToGroup(selectedIds, groupName);
            popup.remove();
        });
        
        // 鼠标悬停效果
        option.addEventListener('mouseover', () => {
            option.style.background = isDarkMode ? '#343541' : '#f0f0f0';
        });
        option.addEventListener('mouseout', () => {
            option.style.background = 'transparent';
        });
    });
    
    // 处理新分组输入
    const newGroupInput = popup.querySelector('.new-group-input');
    newGroupInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            const newGroup = newGroupInput.value.trim();
            if (newGroup) {
                console.log('📝 准备创建新分组:', newGroup);
                
                // 确保当前对话的数据结构存在
                if (!allBookmarks[currentChatId]) {
                    allBookmarks[currentChatId] = {
                        bookmarks: [],
                        groupOrder: ['', ...DEFAULT_EMOJI_GROUPS],
                        groupMap: {}
                    };
                }
                
                // 确保 groupOrder 存在
                if (!allBookmarks[currentChatId].groupOrder) {
                    allBookmarks[currentChatId].groupOrder = ['', ...DEFAULT_EMOJI_GROUPS];
                }
                
                // 检查是否存在重名分组，如果存在则添加数字后缀
                let finalGroupName = newGroup;
                let counter = 1;
                while (allBookmarks[currentChatId].groupOrder.includes(finalGroupName)) {
                    finalGroupName = `${newGroup}(${counter})`;
                    counter++;
                }
                console.log('📝 最终分组名称:', finalGroupName);
                
                // 添加新分组到 groupOrder
                if (!allBookmarks[currentChatId].groupOrder.includes(finalGroupName)) {
                    allBookmarks[currentChatId].groupOrder.push(finalGroupName);
                    console.log('✅ 新分组已添加到 groupOrder:', allBookmarks[currentChatId].groupOrder);
                }
                
                // 确保 groupMap 存在
                if (!allBookmarks[currentChatId].groupMap) {
                    allBookmarks[currentChatId].groupMap = {};
                }
                
                // 初始化新分组的 groupMap
                if (!allBookmarks[currentChatId].groupMap[finalGroupName]) {
                    allBookmarks[currentChatId].groupMap[finalGroupName] = [];
                }
                
                moveBookmarksToGroup(selectedIds, finalGroupName);
                popup.remove();
            }
        }
    });
    
    // 取消按钮
    popup.querySelector('.cancel-move').addEventListener('click', () => {
        popup.remove();
    });
}

// 移动书签到指定分组
function moveBookmarksToGroup(bookmarkIds, groupName) {
    console.log(`🔄 移动书签到分组开始：`, {
        bookmarkIds,
        targetGroup: groupName,
        currentGroups: allBookmarks[currentChatId]?.groupOrder || []
    });
    
    const chatData = allBookmarks[currentChatId];
    if (chatData && Array.isArray(chatData.bookmarks)) {
        chatData.bookmarks.forEach(bm => {
            if (bookmarkIds.includes(bm.id)) {
                const oldGroup = bm.group;
                bm.group = groupName;
                console.log(`📝 书签 ${bm.id} 从 "${oldGroup}" 移动到 "${groupName}"`);
            }
        });
        
        // 确保分组存在于 groupOrder 中
        if (groupName && !chatData.groupOrder.includes(groupName)) {
            chatData.groupOrder.push(groupName);
            console.log(`➕ 添加新分组到排序列表: ${groupName}`, chatData.groupOrder);
        }
        
        saveBookmarksToStorage();
        console.log(`✅ 移动完成，当前分组顺序:`, chatData.groupOrder);
        renderBookmarkList();
    }
}

// 在文件开头添加数据初始化的保护
function ensureCurrentChatData() {
    if (!allBookmarks[currentChatId]) {
        allBookmarks[currentChatId] = {
            bookmarks: [],
            groupOrder: ['', ...DEFAULT_EMOJI_GROUPS],
            groupMap: {}
        };
    }
    return allBookmarks[currentChatId];
}

// 修改拖拽相关的处理函数
function handleBookmarkDrop(e, dragData, targetBookmark) {
    try {
        const currentChatData = ensureCurrentChatData();
        
        const draggedBookmark = currentChatData.bookmarks.find(bm => bm.id === dragData.id);
        if (!draggedBookmark) {
            console.warn('❌ 未找到拖拽的书签');
            return;
        }

        const dragIndex = currentChatData.bookmarks.indexOf(draggedBookmark);
        if (dragIndex === -1) {
            console.warn('❌ 书签索引无效');
            return;
        }

        // 获取目标位置
        const targetIndex = currentChatData.bookmarks.indexOf(targetBookmark);
        if (targetIndex === -1) {
            console.warn('❌ 目标位置无效');
            return;
        }

        // 根据鼠标位置决定插入点
        const rect = e.target.getBoundingClientRect();
        const midY = rect.top + rect.height / 2;
        const insertIndex = e.clientY < midY ? targetIndex : targetIndex + 1;

        // 更新书签分组
        draggedBookmark.group = targetBookmark.group;

        // 移动书签
        const [removed] = currentChatData.bookmarks.splice(dragIndex, 1);
        currentChatData.bookmarks.splice(insertIndex > dragIndex ? insertIndex - 1 : insertIndex, 0, removed);

        console.log('📊 更新书签顺序:', {
            fromGroup: dragData.group,
            toGroup: targetBookmark.group,
            from: dragIndex,
            to: insertIndex,
            bookmark: draggedBookmark.summary
        });

        saveBookmarksToStorage();
        renderBookmarkList();
    } catch (error) {
        console.error('处理拖放时出错:', error);
    }
}

function handleEmptyGroupDrop(e, dragData, groupName) {
    try {
        const currentChatData = ensureCurrentChatData();
        
        const draggedBookmark = currentChatData.bookmarks.find(bm => bm.id === dragData.id);
        if (!draggedBookmark) {
            console.warn('❌ 未找到拖拽的书签');
            return;
        }

        const dragIndex = currentChatData.bookmarks.indexOf(draggedBookmark);
        if (dragIndex === -1) {
            console.warn('❌ 书签索引无效');
            return;
        }

        // 更新书签分组
        draggedBookmark.group = groupName;
        
        // 移动书签（放到组的末尾）
        currentChatData.bookmarks.splice(dragIndex, 1);
        currentChatData.bookmarks.push(draggedBookmark);

        console.log('📊 移动书签到空组:', {
            fromGroup: dragData.group,
            toGroup: groupName,
            bookmark: draggedBookmark.summary
        });

        saveBookmarksToStorage();
        renderBookmarkList();
    } catch (error) {
        console.error('空组 drop 处理出错:', error);
    }
}

// 创建单个书签元素
function createBookmarkElement(bookmark, index, groupBookmarks) {
    const element = document.createElement('div');
    element.className = 'bookmark-item';
    element.dataset.id = bookmark.id;
    element.dataset.index = index;
    element.dataset.group = bookmark.group;
    
    if (isManageMode) {
        element.style.cursor = 'default';  // 在管理模式下使用默认光标
        element.innerHTML = `
            <input type="checkbox" class="bookmark-checkbox" ${selectedBookmarks.has(bookmark.id) ? 'checked' : ''}>
            <span class="bookmark-title">${bookmark.summary}</span>
        `;
        
        const checkbox = element.querySelector('.bookmark-checkbox');
        checkbox.addEventListener('mouseup', (e) => {
            e.stopPropagation();
        });
        
        checkbox.addEventListener('mousedown', (e) => {
            e.stopPropagation();
        });
        
        checkbox.addEventListener('change', (e) => {
            e.stopPropagation();
            if (checkbox.checked) {
                selectedBookmarks.add(bookmark.id);
            } else {
                selectedBookmarks.delete(bookmark.id);
            }
            renderBookmarkList();
        });
    } else {
        element.draggable = false; // 整个元素不可拖拽
        element.style.cursor = 'default'; // 默认光标

        // 先创建HTML结构
        element.innerHTML = `
            <span class="bookmark-title">${bookmark.summary}</span>
            <div class="bookmark-actions">
                <span class="drag-handle" style="
                    cursor: move;
                    padding: 0 4px;
                    opacity: 0.5;
                    user-select: none;
                    display: inline-flex;
                    align-items: center;
                    height: 100%;
                " draggable="true">≡</span>
            </div>
        `;

        // 获取所需的DOM元素引用
        const dragHandle = element.querySelector('.drag-handle');
        const titleElement = element.querySelector('.bookmark-title');
        const bookmarkActions = element.querySelector('.bookmark-actions');

        // 确保所有需要的元素都存在
        if (!dragHandle || !titleElement || !bookmarkActions) {
            console.error('❌ 书签元素创建失败：缺少必要的DOM元素');
            return element;
        }

        // 处理单击和双击事件
        let clickTimer = null;
        titleElement.addEventListener('click', (e) => {
            e.stopPropagation();
            
            // 使用延时来区分单击和双击
            if (clickTimer === null) {
                clickTimer = setTimeout(() => {
                    clickTimer = null;
                    // 单击跳转
                    jumpToBookmark(bookmark);
                }, 200); // 200ms 内如果有第二次点击，则是双击
            }
        });

        titleElement.addEventListener('dblclick', (e) => {
            e.stopPropagation();
            
            // 清除可能的单击定时器
            if (clickTimer) {
                clearTimeout(clickTimer);
                clickTimer = null;
            }
            // 双击编辑
            makeEditable(titleElement, bookmark);
        });

        // 阻止拖拽手柄区域的事件冒泡
        bookmarkActions.addEventListener('mousedown', (e) => {
            e.stopPropagation();
        });

        // 拖拽相关事件
        dragHandle.addEventListener('dragstart', (e) => {
            e.stopPropagation();
            // 清除 tooltip 相关状态
            clearTimeout(tooltipTimeout);
            if (tooltipElement) {
                tooltipElement.remove();
                tooltipElement = null;
            }

            const dragData = {
                type: 'bookmark',
                id: bookmark.id,
                index: index,
                group: bookmark.group,
                summary: bookmark.summary
            };
            e.dataTransfer.setData('text/plain', JSON.stringify(dragData));
            // 将拖拽状态应用到整个书签项
            element.classList.add('dragging');
            e.dataTransfer.effectAllowed = 'move';
            console.log('🔄 开始拖拽书签:', bookmark.summary, '所属分组:', bookmark.group);
        });

        dragHandle.addEventListener('dragend', () => {
            element.classList.remove('dragging');
            clearAllDropIndicators();
            console.log('✅ 结束拖拽书签');
            // 恢复默认状态
            element.style.opacity = '1';
        });

        // 书签项的拖拽放置相关事件
        element.addEventListener('dragover', (e) => {
            e.preventDefault();
            e.stopPropagation();
            
            try {
                const draggingElement = document.querySelector('.bookmark-item.dragging');
                if (!draggingElement) return;
                
                e.dataTransfer.dropEffect = 'move';
                
                const rect = element.getBoundingClientRect();
                const midY = rect.top + rect.height / 2;
                
                clearAllDropIndicators();
                
                if (e.clientY < midY) {
                    element.style.borderTop = '2px solid #2c73d2';
                } else {
                    element.style.borderBottom = '2px solid #2c73d2';
                }
            } catch (error) {
                console.error('dragover 处理出错:', error);
            }
        });

        element.addEventListener('dragleave', (e) => {
            e.preventDefault();
            element.style.borderTop = '';
            element.style.borderBottom = '';
        });

        element.addEventListener('drop', (e) => {
            e.preventDefault();
            e.stopPropagation();
            
            try {
                const dragDataStr = e.dataTransfer.getData('text/plain');
                if (!dragDataStr) {
                    console.warn('❌ 没有找到拖拽数据');
                    return;
                }

                const dragData = JSON.parse(dragDataStr);
                if (!dragData || dragData.type !== 'bookmark') {
                    console.warn('⚠️ 不是书签拖拽');
                    return;
                }

                handleBookmarkDrop(e, dragData, bookmark);
            } catch (error) {
                console.error('处理拖放时出错:', error);
            }
        });

        // 添加 tooltip 相关事件
        let tooltipTimeout = null;
        let tooltipElement = null;

        element.addEventListener('mouseenter', (e) => {
            if (isManageMode || document.querySelector('.bookmark-原文-tooltip')) return;

            tooltipTimeout = setTimeout(() => {
                if (element.classList.contains('dragging')) return;

                tooltipElement = document.createElement('div');
                tooltipElement.className = 'bookmark-原文-tooltip';
                tooltipElement.textContent = bookmark.text || '该书签无详细内容';
                
                document.body.appendChild(tooltipElement);

                // 定位tooltip
                const rect = element.getBoundingClientRect();
                const tooltipRect = tooltipElement.getBoundingClientRect();
                
                // 计算左侧位置（在侧边栏左侧显示）
                let left = rect.left - tooltipRect.width - 10; // 默认显示在左侧，距离10px
                
                // 如果左侧空间不足，改为显示在右侧
                if (left < 10) {
                    left = rect.right + 10;
                }
                
                // 计算垂直位置，尽量居中对齐
                let top = rect.top + (rect.height - tooltipRect.height) / 2;
                
                // 确保tooltip不会超出屏幕顶部或底部
                if (top < 10) {
                    top = 10;
                } else if (top + tooltipRect.height > window.innerHeight - 10) {
                    top = window.innerHeight - tooltipRect.height - 10;
                }

                tooltipElement.style.left = `${left}px`;
                tooltipElement.style.top = `${top}px`;
            }, 300);
        });

        element.addEventListener('mouseleave', () => {
            clearTimeout(tooltipTimeout);
            if (tooltipElement) {
                tooltipElement.remove();
                tooltipElement = null;
            }
        });
    }
    
    return element;
}

// 清理所有拖拽提示线
function clearAllDropIndicators() {
    document.querySelectorAll('.bookmark-item, .bookmark-group').forEach(item => {
        item.style.borderTop = '';
        item.style.borderBottom = '';
        item.style.background = '';
    });
}

function renderBookmarkList() {
    console.log('🎨 开始渲染书签列表');
    
    const container = document.getElementById('gpt-bookmark-list');
    if (!container) {
        console.warn('⚠️ 未找到书签列表容器，重新创建UI');
        createBookmarkUI();
        return;
    }
    
    // 更新管理按钮状态
    const manageBtn = container.querySelector('.manage-btn');
    if (manageBtn) {
                    manageBtn.textContent = isManageMode ? i18n('doneMode') : i18n('selectMode');
    }
    
    // 确保当前对话的数据结构存在
    if (!allBookmarks[currentChatId]) {
        allBookmarks[currentChatId] = {
            bookmarks: [],
            groupOrder: ['', ...DEFAULT_EMOJI_GROUPS]
        };
    }
    const currentChatData = allBookmarks[currentChatId];
    
    // 确保 groupOrder 存在且包含所有必要的分组
    if (!currentChatData.groupOrder) {
        currentChatData.groupOrder = ['', ...DEFAULT_EMOJI_GROUPS];
    }
    
    console.log('📊 当前对话数据:', {
        chatId: currentChatId,
        groupOrder: currentChatData.groupOrder,
        totalBookmarks: currentChatData.bookmarks?.length || 0
    });
    
    // 清除旧内容，保留头部
    const header = container.querySelector('div:first-child');
    const hr = container.querySelector('hr');
    container.innerHTML = '';
    if (header) container.appendChild(header);
    if (hr) container.appendChild(hr);
    
    // 如果在管理模式下，显示分组批量操作按钮
    if (isManageMode) {
        const groupBatchActions = document.createElement('div');
        groupBatchActions.className = 'batch-actions';
        groupBatchActions.style.padding = '8px';
        groupBatchActions.style.marginBottom = '8px';
        
        if (selectedGroups.size > 0) {
            groupBatchActions.innerHTML = `
                <div style="margin-bottom: 8px;">已选择 ${selectedGroups.size} 个分组</div>
                <div style="display: flex; gap: 8px;">
                    <button class="batch-delete-groups-btn" style="
                        padding: 4px 8px;
                        background: #dc3545;
                        color: white;
                        border: none;
                        border-radius: 4px;
                        cursor: pointer;
                    ">${i18n('deleteSelected')}</button>
                </div>
            `;
            
            // 添加批量删除分组事件
            groupBatchActions.querySelector('.batch-delete-groups-btn').onclick = () => {
                const selectedGroupsArray = Array.from(selectedGroups);
                
                if (confirm(`确定要删除选中的 ${selectedGroups.size} 个分组吗？这些分组下的书签将移至默认分组。`)) {
                    console.log('🗑️ 开始批量删除分组:', selectedGroupsArray);
                    
                    selectedGroupsArray.forEach(groupName => {
                        // 将该分组的书签移动到默认分组
                        currentChatData.bookmarks.forEach(bookmark => {
                            if (bookmark.group === groupName) {
                                bookmark.group = '';
                                console.log('📦 移动书签到默认分组:', bookmark.summary);
                            }
                        });
                        
                        // 从 groupOrder 中移除该分组
                        const groupIndex = currentChatData.groupOrder.indexOf(groupName);
                        if (groupIndex !== -1) {
                            currentChatData.groupOrder.splice(groupIndex, 1);
                            console.log('✅ 从分组列表中移除:', groupName);
                        }
                        
                        // 从 groupMap 中移除该分组
                        if (currentChatData.groupMap && currentChatData.groupMap[groupName]) {
                            delete currentChatData.groupMap[groupName];
                            console.log('✅ 从 groupMap 中移除:', groupName);
                        }
                    });
                    
                    selectedGroups.clear();
                    saveBookmarksToStorage();
                    updateQuickActionPopupGroups();
                    renderBookmarkList();
                }
            };
        }
        
        container.appendChild(groupBatchActions);
    }
    
    // 如果在管理模式下且有选中的书签，显示书签批量操作按钮
    if (isManageMode && selectedBookmarks.size > 0) {
        const bookmarkBatchActions = document.createElement('div');
        bookmarkBatchActions.className = 'batch-actions';
        bookmarkBatchActions.style.padding = '8px';
        bookmarkBatchActions.style.marginBottom = '8px';
        
        bookmarkBatchActions.innerHTML = `
            <div style="margin-bottom: 8px;">${i18n('selectedItems', [selectedBookmarks.size])}</div>
                <div style="display: flex; gap: 8px;">
                    <button class="batch-delete-btn" style="
                        padding: 4px 8px;
                        background: #dc3545;
                        color: white;
                        border: none;
                        border-radius: 4px;
                        cursor: pointer;
                    ">${i18n('deleteSelected')}</button>
                    <button class="batch-move-btn" style="
                        padding: 4px 8px;
                        background: #2c73d2;
                        color: white;
                        border: none;
                        border-radius: 4px;
                        cursor: pointer;
                    ">${i18n('moveToGroup')}</button>
                    <button class="batch-export-btn" style="
                        padding: 4px 8px;
                        background: #28a745;
                        color: white;
                        border: none;
                        border-radius: 4px;
                        cursor: pointer;
                    " title="${i18n('exportContentTooltip')}">${i18n('exportContent')}</button>
                </div>
            `;
            
            // 添加批量删除事件
        bookmarkBatchActions.querySelector('.batch-delete-btn').onclick = () => {
                if (confirm(i18n('deleteConfirm', [selectedBookmarks.size]))) {
                currentChatData.bookmarks = currentChatData.bookmarks.filter(bm => !selectedBookmarks.has(bm.id));
                    saveBookmarksToStorage();
                    selectedBookmarks.clear();
                    renderBookmarkList();
                }
            };
            
            // 添加批量移动事件
            bookmarkBatchActions.querySelector('.batch-move-btn').onclick = () => {
                showMoveToGroupPopup(Array.from(selectedBookmarks));
            };

            // 添加导出事件
            bookmarkBatchActions.querySelector('.batch-export-btn').onclick = () => {
                try { // <--- 添加 try 块
                    console.log('📤 开始导出选中的书签内容');
                    const selectedBookmarkIds = Array.from(selectedBookmarks);
                    const selectedBookmarkContents = currentChatData.bookmarks
                        .filter(bm => selectedBookmarkIds.includes(bm.id))
                        .map(bm => bm.text)
                        .join('\n\n');
                    
                    // 检测当前主题模式
                    const isDarkMode = document.documentElement.classList.contains('dark');
                    
                    // 创建导出选项对话框
                    const exportDialog = document.createElement('div');
                    
                    // 定义导出模板
                    const exportTemplates = {
                        raw: {
                            title: i18n('exportRaw'),
                            tooltip: i18n('exportRawTooltip'),
                            prompt: content => i18n('exportRawPrompt') + content,
                            needCustomPrompt: false
                        },
                        quotes: {
                            title: i18n('exportQuotes'),
                            tooltip: i18n('exportQuotesTooltip'),
                            prompt: content => i18n('exportQuotesPrompt') + content,
                            needCustomPrompt: false
                        },
                        structured: {
                            title: i18n('exportStructured'),
                            tooltip: i18n('exportStructuredTooltip'),
                            prompt: content => i18n('exportStructuredPrompt') + content,
                            needCustomPrompt: false
                        },
                        creative: {
                            title: i18n('exportCreative'),
                            tooltip: i18n('exportCreativeTooltip'),
                            prompt: content => i18n('exportCreativePrompt') + content,
                            needCustomPrompt: false
                        },
                        custom: {
                            title: i18n('customPrompt'),
                            tooltip: i18n('customPromptTooltip'),
                            prompt: (content, customPrompt) => customPrompt + '\n\n' + content,
                            needCustomPrompt: true
                        }
                    };

                    exportDialog.style.cssText = `
                        position: fixed;
                        top: 50%;
                        left: 50%;
                        transform: translate(-50%, -50%);
                        background: ${isDarkMode ? '#202123' : 'white'};
                        border: 1px solid ${isDarkMode ? '#4a4b4d' : '#e5e5e5'};
                        border-radius: 8px;
                        padding: 20px;
                        z-index: 10000;
                        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
                        max-width: 500px;
                        width: 90%;
                        color: ${isDarkMode ? '#fff' : '#000'};
                    `;

                    // 创建选项HTML
                    const optionsHTML = Object.entries(exportTemplates).map(([key, template]) => {
                        const isCustom = key === 'custom';
                        const customLabelBackground = isDarkMode ? '#3c4d34' : '#f0fff0';
                        const customLabelBorder = isDarkMode ? '#5a7a44' : '#c8e6c9';

                        return `
                            <label class="export-option" style="
                                display: block;
                                margin-bottom: 12px;
                                padding: 8px;
                                border-radius: 4px;
                                cursor: pointer;
                                position: relative;
                                border: 1px solid ${isCustom ? customLabelBorder : (isDarkMode ? '#4a4b4d' : '#e5e5e5')};
                                background: ${isCustom ? customLabelBackground : (isDarkMode ? '#343541' : 'white')};
                                color: ${isDarkMode ? '#fff' : '#000'};
                            ">
                                <input type="radio" name="exportType" value="${key}" ${key === 'raw' ? 'checked' : ''}>
                                <span style="margin-left: 8px;">${template.title}</span>
                                <div class="tooltip" style="
                                    display: none;
                                    position: absolute;
                                    left: calc(100% + 10px);
                                    top: 50%;
                                    transform: translateY(-50%);
                                    background: ${isDarkMode ? '#202123' : 'white'};
                                    border: 1px solid ${isDarkMode ? '#4a4b4d' : '#e5e5e5'};
                                    padding: 8px 12px;
                                    border-radius: 4px;
                                    width: 200px;
                                    font-size: 12px;
                                    z-index: 10001;
                                    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
                                ">${template.tooltip}</div>
                            </label>
                            ${template.needCustomPrompt ? `
                                <div class="custom-prompt-container" style="
                                    margin-left: 28px;
                                    margin-bottom: 12px;
                                    display: none;
                                ">
                                    <div style="color: ${isDarkMode ? '#a9a9a9' : '#666'};">
                                        <div style="margin-bottom: 8px;">${i18n('customPromptPrefix')}</div>
                                        <input type="text" class="custom-prompt-input" placeholder="${i18n('customPromptPlaceholder')}" style="
                                            width: 100%;
                                            padding: 4px 8px;
                                            border: 1px solid ${isDarkMode ? '#4a4b4d' : '#e5e5e5'};
                                            border-radius: 4px;
                                            background: ${isDarkMode ? '#343541' : 'white'};
                                            color: ${isDarkMode ? '#fff' : '#000'};
                                            line-height: normal;
                                        ">
                                    </div>
                                </div>
                            ` : ''}
                        `;
                    }).join('');

                    exportDialog.innerHTML = `
                        <h3 style="margin: 0 0 8px 0; color: ${isDarkMode ? '#fff' : '#000'};">${i18n('exportToGPT')}</h3>
                        <p style="
                            margin: 0 0 16px 0;
                            font-size: 13px;
                            color: ${isDarkMode ? '#a9a9a9' : '#666'};
                            line-height: 1.5;
                        ">${i18n('exportTip')}<br>
                        ${i18n('hoverTip')}</p>
                        <div class="export-options">
                            ${optionsHTML}
                        </div>
                        <div style="margin-top: 16px;">
                            <button class="cancel-btn" style="
                                padding: 6px 12px;
                                margin-right: 8px;
                                background: transparent;
                                border: 1px solid ${isDarkMode ? '#666' : '#ddd'};
                                color: ${isDarkMode ? '#fff' : '#000'};
                                border-radius: 4px;
                                cursor: pointer;
                            ">${i18n('cancel')}</button>
                            <button class="confirm-btn" style="
                                padding: 6px 12px;
                                background: #10a37f;
                                color: white;
                                border: none;
                                border-radius: 4px;
                                cursor: pointer;
                            ">${i18n('confirmExport')}</button>
                        </div>
                    `;

                    // 添加tooltip和选项交互
                    exportDialog.querySelectorAll('.export-option').forEach(option => {
                        const tooltip = option.querySelector('.tooltip');
                        const radio = option.querySelector('input[type="radio"]');
                        const customPromptInput = option.nextElementSibling?.classList.contains('custom-prompt-input') 
                            ? option.nextElementSibling 
                            : null;
                        
                        option.addEventListener('mouseenter', () => {
                            tooltip.style.display = 'block';
                        });
                        
                        option.addEventListener('mouseleave', () => {
                            tooltip.style.display = 'none';
                        });

                        // 添加选中效果和自定义提示语输入框显示控制
                        option.addEventListener('click', () => {
                            exportDialog.querySelectorAll('.export-option').forEach(opt => {
                                opt.style.borderColor = isDarkMode ? '#4a4b4d' : '#e5e5e5';
                            });
                            option.style.borderColor = '#2c73d2';

                            // 控制自定义提示语输入框的显示/隐藏
                            const customPromptContainer = option.nextElementSibling;
                            exportDialog.querySelectorAll('.custom-prompt-container').forEach(container => {
                                container.style.display = 'none';
                            });
                            if (customPromptContainer && customPromptContainer.classList.contains('custom-prompt-container')) {
                                customPromptContainer.style.display = 'block'; // 修改这里，从 'flex' 改为 'block'
                            }
                        });
                    });
                    
                    // 添加遮罩层
                    const overlay = document.createElement('div');
                    overlay.style.cssText = `
                        position: fixed;
                        top: 0;
                        left: 0;
                        right: 0;
                        bottom: 0;
                        background: ${isDarkMode ? 'rgba(0, 0, 0, 0.7)' : 'rgba(0, 0, 0, 0.5)'};
                        z-index: 9999;
                    `;
                    
                    document.body.appendChild(overlay);
                    document.body.appendChild(exportDialog);
                    
                    // 处理取消按钮
                    exportDialog.querySelector('.cancel-btn').onclick = () => {
                        overlay.remove();
                        exportDialog.remove();
                    };
                    
                    // 处理确认按钮
                    exportDialog.querySelector('.confirm-btn').onclick = () => {
                        const exportType = exportDialog.querySelector('input[name="exportType"]:checked').value;
                        const template = exportTemplates[exportType];
                        let finalContent;

                        if (template.needCustomPrompt) {
                            const customPromptInput = exportDialog.querySelector('.custom-prompt-input');
                            if (!customPromptInput) {
                                console.error('❌ 未找到自定义提示语输入框');
                                alert('发生错误：找不到自定义提示输入框');
                                return;
                            }
                            const customPrompt = customPromptInput.value.trim();
                            
                            if (!customPrompt) {
                                showMessage('pleaseEnterPrompt');
                                return;
                            }
                            
                            finalContent = template.prompt(selectedBookmarkContents, customPrompt);
                        } else {
                            finalContent = template.prompt(selectedBookmarkContents);
                        }
                        
                        // 复制到剪贴板
                        navigator.clipboard.writeText(finalContent)
                            .then(() => {
                                showMessage('copySuccess');
                                overlay.remove();
                                exportDialog.remove();
                            })
                            .catch(err => {
                                console.error('Copy failed:', err);
                                showMessage('copyFailed');
                            });
                        
                        // 关闭对话框
                        overlay.remove();
                        exportDialog.remove();
                    };
                } catch (e) { // <--- 添加 catch 块
                    console.error("导出按钮点击处理时发生错误:", e);
                    alert("导出时发生错误，请打开浏览器控制台查看详情。");
                }
            };
        
        container.appendChild(bookmarkBatchActions);
    }
    
    // 按分组整理书签
    const bookmarksByGroup = {};
    currentChatData.groupOrder.forEach(groupName => {
        bookmarksByGroup[groupName] = [];
    });
    
    // 将书签分配到对应分组
    currentChatData.bookmarks.forEach(bookmark => {
        const group = bookmark.group || '';
        if (!bookmarksByGroup[group]) {
            bookmarksByGroup[group] = [];
            if (!currentChatData.groupOrder.includes(group)) {
                currentChatData.groupOrder.push(group);
            }
        }
        bookmarksByGroup[group].push(bookmark);
    });
    
    // 渲染分组
    currentChatData.groupOrder.forEach((groupName, index) => {
                    const groupContainer = document.createElement('div');
        const groupBookmarks = bookmarksByGroup[groupName] || [];
        groupContainer.className = `bookmark-group ${groupBookmarks.length === 0 ? 'empty' : ''}`;
        groupContainer.dataset.group = groupName;
        groupContainer.dataset.index = index;
        groupContainer.style.marginBottom = '12px';
        
        // 只在非管理模式下启用拖拽
        if (!isManageMode) {
            groupContainer.draggable = true;
            groupContainer.style.cursor = 'move';
            
            groupContainer.addEventListener('dragstart', (e) => {
                e.stopPropagation();
                groupContainer.classList.add('dragging');
                const dragData = {
                    type: 'group',
                    group: groupName,
                    index: index
                };
                e.dataTransfer.setData('text/plain', JSON.stringify(dragData));
                console.log('🔄 开始拖拽分组:', groupName);
            });

            groupContainer.addEventListener('dragend', () => {
                groupContainer.classList.remove('dragging');
                clearAllDropIndicators();
                console.log('✅ 结束拖拽分组');
            });

            groupContainer.addEventListener('dragover', (e) => {
                e.preventDefault();
                e.stopPropagation();
                
                try {
                    const draggingGroup = document.querySelector('.bookmark-group.dragging');
                    if (!draggingGroup || draggingGroup === groupContainer) return;

                    const rect = groupContainer.getBoundingClientRect();
                    const midY = rect.top + rect.height / 2;
                    
                    clearAllDropIndicators();
                    
                    if (e.clientY < midY) {
                        groupContainer.style.borderTop = '2px solid #2c73d2';
                        } else {
                        groupContainer.style.borderBottom = '2px solid #2c73d2';
                    }
                } catch (error) {
                    console.error('dragover 处理出错:', error);
                }
            });

            groupContainer.addEventListener('dragleave', () => {
                groupContainer.style.borderTop = '';
                groupContainer.style.borderBottom = '';
            });

            groupContainer.addEventListener('drop', (e) => {
                e.preventDefault();
                e.stopPropagation();
                
                try {
                    const dragDataStr = e.dataTransfer.getData('text/plain');
                    if (!dragDataStr) {
                        console.warn('❌ 没有找到拖拽数据');
                        return;
                    }

                    const dragData = JSON.parse(dragDataStr);
                    if (!dragData || dragData.type !== 'group') {
                        console.warn('⚠️ 不是分组拖拽');
                        return;
                    }

                    const draggedIndex = parseInt(dragData.index);
                    const dropIndex = parseInt(groupContainer.dataset.index);
                    
                    if (draggedIndex === dropIndex || isNaN(draggedIndex) || isNaN(dropIndex)) {
                        console.warn('❌ 拖拽索引无效');
                        return;
                    }
                    
                    const rect = groupContainer.getBoundingClientRect();
                    const midY = rect.top + rect.height / 2;
                    const insertIndex = e.clientY < midY ? dropIndex : dropIndex + 1;
                    
                    // 移动分组
                    const [removed] = currentChatData.groupOrder.splice(draggedIndex, 1);
                    currentChatData.groupOrder.splice(insertIndex > draggedIndex ? insertIndex - 1 : insertIndex, 0, removed);
                    
                    console.log('📊 更新分组顺序:', {
                        from: draggedIndex,
                        to: insertIndex,
                        group: dragData.group
                    });

                    clearAllDropIndicators();
                    saveBookmarksToStorage();
                    renderBookmarkList();
                } catch (error) {
                    console.error('处理拖放时出错:', error);
                }
            });
        }
        
        // 创建分组标题
        const groupHeader = document.createElement('div');
        groupHeader.className = 'group-header';
        groupHeader.style.padding = '8px';
        groupHeader.style.backgroundColor = document.documentElement.classList.contains('dark') ? '#343541' : '#f5f5f5';
        groupHeader.style.borderRadius = '4px';
        groupHeader.style.marginBottom = '8px';
        
        const titleContainer = document.createElement('div');
        titleContainer.style.display = 'flex';
        titleContainer.style.alignItems = 'center';
        titleContainer.style.justifyContent = 'space-between';
        
        const titleArea = document.createElement('div');
        titleArea.style.display = 'flex';
        titleArea.style.alignItems = 'center';
        titleArea.style.gap = '8px';
        
        // 在管理模式下，为非默认分组添加复选框
        if (isManageMode && groupName !== '') {
            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.className = 'group-checkbox';
            checkbox.checked = selectedGroups.has(groupName);
            checkbox.style.marginRight = '8px';
            checkbox.style.cursor = 'pointer';
            
            // 阻止复选框事件冒泡
            checkbox.addEventListener('mouseup', (e) => {
                e.stopPropagation();
            });
            
            checkbox.addEventListener('mousedown', (e) => {
                e.stopPropagation();
            });
            
            checkbox.onchange = (e) => {
                e.stopPropagation();
                if (checkbox.checked) {
                    selectedGroups.add(groupName);
                    // 选中该分组下的所有书签
                    const groupBookmarks = bookmarksByGroup[groupName] || [];
                    groupBookmarks.forEach(bookmark => {
                        selectedBookmarks.add(bookmark.id);
                    });
                } else {
                    selectedGroups.delete(groupName);
                    // 取消选中该分组下的所有书签
                    const groupBookmarks = bookmarksByGroup[groupName] || [];
                    groupBookmarks.forEach(bookmark => {
                        selectedBookmarks.delete(bookmark.id);
                    });
                }
                renderBookmarkList();
            };
            
            titleArea.appendChild(checkbox);
        }
        
        const groupTitle = document.createElement('div');
        groupTitle.className = 'group-title';
                    groupTitle.textContent = groupName ? (DEFAULT_EMOJI_GROUPS.includes(groupName) ? groupName : groupName) : i18n('defaultGroup');
        titleArea.appendChild(groupTitle);
        
        const bookmarkCount = document.createElement('span');
        bookmarkCount.style.fontSize = '12px';
        bookmarkCount.style.color = '#666';
        bookmarkCount.textContent = `(${bookmarksByGroup[groupName]?.length || 0})`;
        titleArea.appendChild(bookmarkCount);
        
        titleContainer.appendChild(titleArea);
        groupHeader.appendChild(titleContainer);
        groupContainer.appendChild(groupHeader);
        
        // 创建书签容器
        const bookmarksContainer = document.createElement('div');
        bookmarksContainer.className = 'bookmarks-container';
        bookmarksContainer.style.position = 'relative';
        
        // 渲染该分组的书签（使用上面已经声明的groupBookmarks变量）
        
        // 如果是空组，调整样式
        if (groupBookmarks.length === 0) {
            groupContainer.style.marginBottom = '6px';
            groupHeader.style.marginBottom = '4px';
            groupHeader.style.padding = '6px 8px';
            groupHeader.style.opacity = '0.7';
        }
        
        // 如果是空组且在非管理模式下，添加拖拽接收功能
        if (groupBookmarks.length === 0 && !isManageMode) {
            bookmarksContainer.className = 'bookmarks-container empty-hint';
            bookmarksContainer.textContent = '拖拽书签到这里';
            
            bookmarksContainer.addEventListener('dragover', (e) => {
                e.preventDefault();
                e.stopPropagation();
                
                try {
                    const draggingElement = document.querySelector('.bookmark-item.dragging');
                    if (!draggingElement) return;
                    
                    e.dataTransfer.dropEffect = 'move';
                    bookmarksContainer.style.background = 'rgba(44, 115, 210, 0.1)';
                    bookmarksContainer.style.opacity = '1';
                } catch (error) {
                    console.error('空组 dragover 处理出错:', error);
                }
            });
            
            bookmarksContainer.addEventListener('dragleave', () => {
                bookmarksContainer.style.background = '';
                bookmarksContainer.style.opacity = '0.5';
            });
            
            bookmarksContainer.addEventListener('drop', (e) => {
                e.preventDefault();
                e.stopPropagation();
                
                try {
                    const dragDataStr = e.dataTransfer.getData('text/plain');
                    if (!dragDataStr) {
                        console.warn('❌ 没有找到拖拽数据');
                        return;
                    }

                    const dragData = JSON.parse(dragDataStr);
                    if (!dragData || dragData.type !== 'bookmark') {
                        console.warn('⚠️ 不是书签拖拽');
                        return;
                    }

                    handleEmptyGroupDrop(e, dragData, groupName);
                    bookmarksContainer.style.background = '';
                    bookmarksContainer.style.opacity = '0.5';
                } catch (error) {
                    console.error('空组 drop 处理出错:', error);
                }
            });
        } else if (groupBookmarks.length === 0) {
            // 管理模式下的空组，显示更简洁
            bookmarksContainer.style.minHeight = '10px';
            bookmarksContainer.style.opacity = '0.3';
        } else {
            // 非空组，正常渲染书签
            groupBookmarks.forEach((bookmark, index) => {
                const bookmarkElement = createBookmarkElement(bookmark, index, groupBookmarks);
                bookmarksContainer.appendChild(bookmarkElement);
            });
        }
        
        groupContainer.appendChild(bookmarksContainer);
        container.appendChild(groupContainer);
    });
}

// 🎨 创建样式
function createStyles() {
    console.log("🎨 [Debug] createStyles: Creating styles...");
    
    // 清除所有可能残留的旧样式
    const existingStyles = document.querySelectorAll('style[data-gpt-burger], style');
    existingStyles.forEach(style => {
        if (style.textContent && (
            style.textContent.includes('gpt-burger-extension-root') ||
            style.textContent.includes('gpt-bookmark-toggle') ||
            style.textContent.includes('gpt-bookmark-list')
        )) {
            console.log("🗑️ [Debug] createStyles: Removing old style element");
            style.remove();
        }
    });
    
    const style = document.createElement("style");
    style.setAttribute('data-gpt-burger', 'v1.3.5');

    const cssContent = `
        /* ===== DEBUG INDICATOR ===== */
        #gpt-burger-debug-indicator {
            position: fixed;
            top: 5px;
            left: 5px;
            padding: 5px;
            background-color: red;
            color: white;
            z-index: 99999;
            font-size: 10px;
            border: 1px solid white;
            text-align: center;
        }

        /* ===== TOGGLE BUTTON ===== */
        .gpt-bookmark-toggle {
            position: fixed;
            top: 100px;
            right: 20px;
            width: 40px;
            height: 40px;
            border: 1px solid #ccc;
            border-radius: 50%;
            background: white;
            cursor: pointer;
            z-index: 10000;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.15);
            transition: all 0.3s ease;
        }
        
        .gpt-bookmark-toggle:hover {
            transform: scale(1.1);
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        }
        
        html.dark .gpt-bookmark-toggle {
            background: #202123;
            border-color: #4a4b4d;
            color: #fff;
        }
        
        /* ===== BOOKMARK LIST ===== */
        .gpt-bookmark-list {
            position: fixed;
            top: 100px;
            right: 70px;
            width: 220px;
            max-height: 450px;
            z-index: 9999;
            background: white;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 14px;
            font-family: sans-serif;
            transition: all 0.3s ease;
            box-shadow: 0 2px 8px rgba(0,0,0,0.15);
            overflow-y: auto;
            -ms-overflow-style: none;
            scrollbar-width: none;
        }

        .gpt-bookmark-list::-webkit-scrollbar {
            display: none;
        }
        
        .gpt-bookmark-list.collapsed {
            opacity: 0;
            visibility: hidden;
            transform: translateX(30px) scale(0.95);
            pointer-events: none;
        }
        
        .bookmark-content {
            padding: 10px;
        }
        
        html.dark .gpt-bookmark-list {
            background: #202123;
            border-color: #4a4b4d;
            color: #fff;
        }
        
        /* ===== OTHER STYLES ===== */
        .bookmark-group {
            margin-bottom: 8px;
        }
        
        .bookmark-group.empty {
            margin-bottom: 4px;
        }
        
        .bookmark-group.empty .group-header {
            margin-bottom: 4px !important;
            padding: 6px 8px !important;
            opacity: 0.7 !important;
        }
        
        .bookmarks-container.empty-hint {
            min-height: 20px;
            border: 1px dashed #ccc;
            border-radius: 4px;
            margin: 2px 0;
            opacity: 0.5;
            text-align: center;
            font-size: 11px;
            color: #999;
            padding: 2px;
            transition: all 0.2s ease;
        }
        
        .bookmarks-container.empty-hint:hover {
            opacity: 0.8;
        }
        
        html.dark .bookmarks-container.empty-hint {
            border-color: #4a4b4d;
            color: #666;
        }
        
        .group-header {
            margin-bottom: 8px;
            padding: 4px;
            border-radius: 4px;
        }
        
        .group-title {
            font-weight: 500;
        }
        
        html.dark .group-header {
            background: #343541;
        }
        
        .bookmark-item {
            display: flex;
            align-items: center;
            padding: 4px 8px;
            margin: 4px 0;
            border-radius: 4px;
            background: #f5f5f5;
            cursor: move;
            user-select: none;
        }
        
        html.dark .bookmark-item {
            background: #343541;
        }
        
        .bookmark-item.dragging {
            opacity: 0.5;
            background: #f0f0f0;
        }
        
        .bookmark-title {
            flex: 1;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        
        .bookmark-actions {
            display: flex;
            gap: 4px;
            margin-left: 8px;
        }
        
        .bookmark-actions button {
            border: none;
            background: none;
            cursor: pointer;
            padding: 2px 4px;
            opacity: 0.7;
            transition: opacity 0.2s;
        }
        
        .bookmark-actions button:hover {
            opacity: 1;
        }
        
        .bookmark-checkbox {
            margin-right: 8px;
        }
        
        .group-checkbox {
            margin-right: 4px;
            cursor: pointer;
        }
        
        .batch-actions button:hover {
            opacity: 0.9;
        }
        
        html.dark .batch-actions {
            background: #343541;
        }
        
        .bookmark-group:not(.managing) {
            cursor: move;
            user-select: none;
        }
        
        .bookmark-group.dragging {
            opacity: 0.5;
            background: #f0f0f0;
        }
        
        .bookmark-group.drag-target {
            background: rgba(44, 115, 210, 0.1);
        }

        /* ===== TOOLTIP ===== */
        .bookmark-原文-tooltip {
            position: fixed;
            background: rgba(255, 255, 255, 0.8);
            color: #333;
            border: 1px solid #ccc;
            padding: 10px;
            border-radius: 4px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.15);
            z-index: 10001;
            max-width: 350px;
            font-size: 13px;
            line-height: 1.5;
            word-wrap: break-word;
            pointer-events: none;
            white-space: pre-wrap;
        }

        html.dark .bookmark-原文-tooltip {
            background: rgba(40, 42, 46, 0.8);
            color: #c9c9c9;
            border-color: #4a4b4d;
        }
    `;

    style.textContent = cssContent;
    document.head.appendChild(style);
    
    console.log("🎨 [Debug] createStyles: Styles appended to head. CSS length:", cssContent.length);
    console.log("🎨 [Debug] createStyles: Using v1.3.4 style approach - no root container");
}

// 🔵 添加书签到当前对话
function addBookmarkToCurrentChat(bookmark) {
    console.log('📥 开始添加书签到当前对话', {
        currentChatId,
        bookmark
    });

    if (!allBookmarks[currentChatId]) {
        console.log('📁 为当前对话创建新的存储空间');
        allBookmarks[currentChatId] = {
            bookmarks: [],
            groupOrder: ['', ...DEFAULT_EMOJI_GROUPS],  // 确保有默认分组和预设 emoji 分组
            groupMap: {}
        };
    }

    // 确保存在 groupOrder 且包含所有预设 emoji
    if (!allBookmarks[currentChatId].groupOrder) {
        allBookmarks[currentChatId].groupOrder = ['', ...DEFAULT_EMOJI_GROUPS];
    } else {
        const missingEmojis = DEFAULT_EMOJI_GROUPS.filter(emoji => !allBookmarks[currentChatId].groupOrder.includes(emoji));
        if (missingEmojis.length > 0) {
            const defaultIndex = allBookmarks[currentChatId].groupOrder.indexOf('');
            allBookmarks[currentChatId].groupOrder.splice(defaultIndex + 1, 0, ...missingEmojis);
        }
    }

    // 确保存在 groupMap
    if (!allBookmarks[currentChatId].groupMap) {
        allBookmarks[currentChatId].groupMap = {};
    }

    const chatData = allBookmarks[currentChatId];
    console.log('📊 当前对话数据：', chatData);

    chatData.bookmarks.push(bookmark);
    console.log('✅ 书签已添加到数组');

    if (bookmark.group) {
        if (!chatData.groupMap[bookmark.group]) {
            chatData.groupMap[bookmark.group] = [];
            // 如果是新分组且不是预设 emoji，添加到 groupOrder
            if (!chatData.groupOrder.includes(bookmark.group) && !DEFAULT_EMOJI_GROUPS.includes(bookmark.group)) {
                chatData.groupOrder.push(bookmark.group);
            }
            console.log('📁 创建新的分组：', bookmark.group);
        }
        chatData.groupMap[bookmark.group].push(bookmark.id);
        console.log('✅ 书签已添加到分组');
    }

    console.log('💾 准备保存到 localStorage');
    saveBookmarksToStorage();
    console.log('✅ 保存完成');
}

// 创建快速操作弹窗
function createQuickActionPopup() {
    console.log('🔧 开始创建快速操作弹窗');
    
    // 检查文档中是否已存在弹窗
    const existingPopups = document.querySelectorAll('#quick-action-popup');
    console.log(`🔍 文档中已有 ${existingPopups.length} 个弹窗`);
    
    // 如果已存在，先移除旧的
    const existingPopup = document.getElementById('quick-action-popup');
    if (existingPopup) {
        console.log('🗑️ 移除已存在的弹窗');
        existingPopup.remove();
    }
    
    const popup = document.createElement('div');
    popup.className = 'quick-action-popup';
    popup.id = 'quick-action-popup';
    
    // 根据主题设置样式
    const isDarkMode = document.documentElement.classList.contains('dark');
    popup.style.cssText = `
        display: none;
        position: fixed;
        z-index: 9999;
        background: ${isDarkMode ? '#202123' : '#ffffff'};
        color: ${isDarkMode ? '#fff' : '#000'};
        border: 1px solid ${isDarkMode ? '#4a4b4d' : '#e5e5e5'};
        border-radius: 6px;
        padding: 8px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    `;
    
    // 创建一个变量来存储选中的表情
    let selectedEmoji = '';
    
    const content = document.createElement('div');
    content.innerHTML = `
        <div class="quick-action-header">
            <input type="text" 
                placeholder="${i18n('writeNotes')}" 
                class="quick-action-input" 
                style="
                    width: 150px; 
                    padding: 4px; 
                    border: 1px solid ${isDarkMode ? '#4a4b4d' : '#ccc'}; 
                    border-radius: 4px;
                    background: ${isDarkMode ? '#343541' : 'white'};
                    color: ${isDarkMode ? '#fff' : '#000'};
                ">
            <button class="quick-action-save" 
                style="
                    cursor: pointer; 
                    padding: 4px 8px; 
                    background: #2c73d2; 
                    color: white; 
                    border: none; 
                    border-radius: 4px;
                ">${i18n('save')}</button>
        </div>
        <div class="quick-action-groups" style="display: flex; gap: 8px; margin-top: 8px;">
            ${DEFAULT_EMOJI_GROUPS.map(emoji => `
                <span class="group-emoji" style="cursor: pointer; padding: 2px 4px;" data-emoji="${emoji}">${emoji}</span>
            `).join('')}
            <button class="new-group-btn" 
                style="
                    cursor: pointer; 
                    padding: 2px 4px; 
                    background: none; 
                    border: 1px dashed ${isDarkMode ? '#4a4b4d' : '#ccc'}; 
                    border-radius: 4px;
                    color: ${isDarkMode ? '#fff' : '#000'};
                ">${i18n('newGroup')}</button>
        </div>
        <div class="new-group-form" style="display: none; margin-top: 8px;">
            <div style="display: flex; gap: 8px; align-items: center;">
                <input type="text" 
                    placeholder="${i18n('enterGroupName')}" 
                    class="new-group-input" 
                    style="
                        flex: 1;
                        padding: 4px; 
                        border: 1px solid ${isDarkMode ? '#4a4b4d' : '#ccc'}; 
                        border-radius: 4px;
                        background: ${isDarkMode ? '#343541' : 'white'};
                        color: ${isDarkMode ? '#fff' : '#000'};
                    ">
                <button class="confirm-new-group" 
                    style="
                        cursor: pointer; 
                        padding: 4px 8px; 
                        background: #2c73d2; 
                        color: white; 
                        border: none; 
                        border-radius: 4px;
                    ">${i18n('confirm')}</button>
                <button class="cancel-new-group" 
                    style="
                        cursor: pointer; 
                        padding: 4px 8px; 
                        background: ${isDarkMode ? '#343541' : '#f0f0f0'}; 
                        color: ${isDarkMode ? '#fff' : '#666'}; 
                        border: none; 
                        border-radius: 4px;
                    ">${i18n('cancel')}</button>
            </div>
        </div>
    `;
    
    popup.appendChild(content);
    document.body.appendChild(popup);
    
    const input = popup.querySelector('.quick-action-input');
    const saveButton = popup.querySelector('.quick-action-save');
    const emojiSpans = popup.querySelectorAll('.group-emoji');
    const newGroupBtn = popup.querySelector('.new-group-btn');
    const newGroupForm = popup.querySelector('.new-group-form');
    const newGroupInput = popup.querySelector('.new-group-input');
    const confirmNewGroupBtn = popup.querySelector('.confirm-new-group');
    const cancelNewGroupBtn = popup.querySelector('.cancel-new-group');
    
    // 选择表情
    emojiSpans.forEach(span => {
        span.onclick = (e) => {
            e.stopPropagation();
            console.log('🎯 点击了表情：', span.dataset.emoji);
            
            // 确保当前对话的数据结构存在
            const currentChatData = ensureCurrentChatData();
            
            const emoji = span.dataset.emoji;
            
            if (selectedEmoji === emoji) {
                span.style.background = 'none';
                selectedEmoji = '';
                console.log('取消选择表情');
            } else {
                emojiSpans.forEach(s => s.style.background = 'none');
                span.style.background = isDarkMode ? '#343541' : '#e3f2fd';
                span.style.borderRadius = '6px';
                selectedEmoji = emoji;
                console.log('选择新表情：', selectedEmoji);
            }
            
            // 保存更新后的分组顺序
            saveBookmarksToStorage();
        };
    });
    
    // 新分组按钮点击事件
    newGroupBtn.onclick = () => {
        newGroupForm.style.display = 'block';
        newGroupInput.focus();
    };
    
    // 确认创建新分组
    confirmNewGroupBtn.onclick = () => {
        const groupName = newGroupInput.value.trim();
        if (groupName) {
            console.log('📝 准备创建新分组:', groupName);
            
            // 确保当前对话的数据结构存在
            const currentChatData = ensureCurrentChatData();
            
            // 检查是否存在重名分组，如果存在则添加数字后缀
            let finalGroupName = groupName;
            let counter = 1;
            while (currentChatData.groupOrder.includes(finalGroupName)) {
                finalGroupName = `${groupName}(${counter})`;
                counter++;
            }
            console.log('📝 最终分组名称:', finalGroupName);
            
            // 添加新分组到 groupOrder
            if (!currentChatData.groupOrder.includes(finalGroupName)) {
                currentChatData.groupOrder.push(finalGroupName);
                console.log('✅ 新分组已添加到 groupOrder:', currentChatData.groupOrder);
            }
            
            // 确保 groupMap 存在
            if (!currentChatData.groupMap) {
                currentChatData.groupMap = {};
            }
            
            // 初始化新分组的 groupMap
            if (!currentChatData.groupMap[finalGroupName]) {
                currentChatData.groupMap[finalGroupName] = [];
            }
            
            selectedEmoji = finalGroupName;
            newGroupForm.style.display = 'none';
            newGroupInput.value = '';
            
            // 添加新的分组选项
            const newGroupSpan = document.createElement('span');
            newGroupSpan.className = 'group-emoji';
            newGroupSpan.dataset.emoji = finalGroupName;
            newGroupSpan.textContent = finalGroupName;
            newGroupSpan.style.cssText = `
                cursor: pointer; 
                padding: 2px 4px;
                background: ${isDarkMode ? '#343541' : '#e3f2fd'};
                border-radius: 6px;
            `;
            
            // 添加点击事件
            newGroupSpan.onclick = (e) => {
                e.stopPropagation();
                emojiSpans.forEach(s => s.style.background = 'none');
                newGroupSpan.style.background = isDarkMode ? '#343541' : '#e3f2fd';
                selectedEmoji = finalGroupName;
            };
            
            // 添加到列表
            newGroupBtn.parentNode.insertBefore(newGroupSpan, newGroupBtn);
            
            // 保存更新
            saveBookmarksToStorage();
            
            // 重新渲染书签列表
            renderBookmarkList();
        }
    };
    
    // 取消创建新分组
    cancelNewGroupBtn.onclick = () => {
        newGroupForm.style.display = 'none';
        newGroupInput.value = '';
    };
    
    // 保存按钮点击
    saveButton.onclick = (e) => {
        console.log('🔵 点击保存按钮');
        e.stopPropagation();
        
        if (!tempBookmark) {
            console.warn('❌ 没有找到临时书签');
            alert('请重新选择要保存的文本');
            return;
        }
        
        // 更新临时书签
        tempBookmark.summary = input.value.trim() || tempBookmark.summary;
        tempBookmark.group = selectedEmoji;
        console.log('📝 更新后的书签：', tempBookmark);
        
        try {
            // 确保当前对话的数据结构存在
            const currentChatData = ensureCurrentChatData();
            
            // 保存书签
            addBookmarkToCurrentChat(tempBookmark);
            console.log('✅ 书签保存成功');
            
            // 展开书签边栏以显示新创建的书签
            showBookmarkSidebar();
            
            // 更新显示
            renderBookmarkList();
            console.log('✅ 书签列表已更新');
            
            // 高亮显示新创建的书签
            highlightNewBookmark(tempBookmark.id);
            
            // 重置状态
            popup.style.display = 'none';
            input.value = '';
            selectedEmoji = '';
            tempBookmark = null;
            emojiSpans.forEach(s => s.style.background = 'none');
            console.log('✅ 所有状态已重置');
        } catch (error) {
            console.error('❌ 保存书签时出错：', error);
            alert('保存书签时出错，请重试');
        }
    };
    
    // 回车保存
    input.onkeydown = (e) => {
        if (e.key === 'Enter') {
            console.log('⌨️ 按下回车键');
            e.preventDefault();
            saveButton.click();
        }
    };
    
    // 阻止冒泡
    popup.onmousedown = (e) => e.stopPropagation();
    
    // 点击外部关闭
    document.addEventListener('mousedown', (e) => {
        if (popup && !popup.contains(e.target)) {
            // 延迟关闭弹窗，给用户时间进行复制操作
            setTimeout(() => {
            popup.style.display = 'none';
            tempBookmark = null;
                selectedEmoji = '';
            }, 200);
        }
    });
    
    console.log('✅ 快速操作弹窗创建完成');
    return popup;
}

// 选中文本显示弹窗
document.addEventListener('mouseup', (e) => {
    // 如果在管理模式下，不显示弹窗
    if (isManageMode) {
        return;
    }

    console.log('🎯 检测到鼠标抬起事件');
    
    // 保存当前选中的文本和范围
    const selection = window.getSelection();
    const selectedText = selection.toString().trim();
    console.log('📝 选中的文本：', selectedText);
    
    if (selectedText && selectedText.length >= 1) {
        let node = selection.anchorNode;
        while (node && node.nodeType === 3) {
            node = node.parentNode;
        }
        
        const article = node.closest('article');
        if (article) {
            console.log('✅ 找到文本所在的文章块');
            
            // 获取上下文（只在选中节点内）
            let contextBefore = '';
            let contextAfter = '';
            if (selectedText.length < 15) {
                const textNode = selection.anchorNode;
                // 计算选中内容在节点内的起止位置
                const startOffset = Math.min(selection.anchorOffset, selection.focusOffset);
                const endOffset = Math.max(selection.anchorOffset, selection.focusOffset);
                // 获取前文（最多20字）
                contextBefore = textNode.textContent.slice(Math.max(0, startOffset - 20), startOffset);
                // 获取后文（最多20字）
                contextAfter = textNode.textContent.slice(endOffset, endOffset + 20);
                console.log('📝 节点内上下文:', {
                    前文: contextBefore,
                    选中: selectedText,
                    后文: contextAfter
                });
            }
            
            // 创建临时书签，保存选中的文本
            tempBookmark = {
                id: `bookmark-${Date.now()}`,
                summary: selectedText.slice(0, 30).replace(/\n/g, " "),
                text: selectedText,
                articleId: article.dataset.testid,
                offset: article.offsetTop,
                contextBefore,
                contextAfter,
                group: '',  // 分组留空，等用户选择
                // 🆕 增强的位置信息
                containerInfo: analyzeSelectionContainer(selection, article, selectedText) // 传入用户选中的文本
            };
            
            // 打印详细的调试信息
            console.log('📝 创建书签:', {
                text: tempBookmark.text,
                length: tempBookmark.text.length,
                hasContext: tempBookmark.text.length < 15,
                contextBefore: tempBookmark.contextBefore,
                contextAfter: tempBookmark.contextAfter,
                articleId: tempBookmark.articleId,
                // 🆕 新增的容器信息日志
                containerInfo: tempBookmark.containerInfo
            });

            // 确保弹窗存在
            let popup = document.getElementById('quick-action-popup');
            console.log('🔍 查找快速操作弹窗:', popup ? '已存在' : '不存在');
            
            if (!popup) {
                console.log('🔄 弹窗不存在，开始创建...');
                popup = createQuickActionPopup();
                console.log('✅ 创建弹窗结果:', popup ? '成功' : '失败');
                
                // 如果创建失败，再次尝试获取
                if (!popup) {
                    popup = document.getElementById('quick-action-popup');
                    console.log('🔄 再次查找弹窗:', popup ? '找到了' : '仍然不存在');
                }
            }

            if (popup) {
                const input = popup.querySelector('.quick-action-input');
                console.log('🔍 查找输入框:', input ? '已找到' : '未找到');
                
                if (input) {
                    input.value = tempBookmark.summary;
                    
                    // 重置表情选择
                    popup.querySelectorAll('.group-emoji').forEach(s => s.style.background = 'none');
                    
                    // 显示在鼠标位置并确保可见
                    popup.style.left = `${e.clientX + 5}px`;
                    popup.style.top = `${e.clientY + 5}px`;
                    popup.style.display = 'block';
                    popup.style.opacity = '1';
                    popup.style.zIndex = '9999';  // 确保在最顶层
                    
                    console.log('✨ 显示快速操作弹窗', {
                        位置: {x: e.clientX + 5, y: e.clientY + 5},
                        显示状态: popup.style.display,
                        不透明度: popup.style.opacity,
                        层级: popup.style.zIndex
                    });
                    
                    // 聚焦输入框 (❗已移除，以防止取消文本选择)
                    // setTimeout(() => {
                    //     input.focus();
                    //     console.log('✨ 聚焦输入框');
                    // }, 100);
                } else {
                    console.warn('❌ 未找到输入框元素');
                }
                } else {
                console.warn('❌ 未找到弹窗元素');
            }
        }
    }
});

// 确保在页面加载完成后初始化插件
if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initPlugin);
  } else {
    initPlugin();
  }

let lastChatId = currentChatId;

// 每 1 秒检查 URL 是否变动
setInterval(() => {
    const newChatId = getCurrentChatId();
    if (newChatId !== lastChatId) {
      lastChatId = newChatId;
      currentChatId = newChatId;
  
      waitForArticlesAndRender(); // ✅ 等 article 加载完再插入锚点
  
      console.log("📄 检测到对话切换，等待页面加载后刷新书签！");
    }
}, 1000);

// 更新快速操作弹窗的分组列表
function updateQuickActionPopupGroups() {
    console.log('🔄 更新快速操作弹窗的分组列表');
    const popup = document.getElementById('quick-action-popup');
    if (!popup) {
        console.log('⚠️ 未找到快速操作弹窗');
        return;
    }

    const groupsContainer = popup.querySelector('.quick-action-groups');
    if (!groupsContainer) {
        console.log('⚠️ 未找到分组容器');
        return;
    }

    // 保存新建分组按钮
    const newGroupBtn = groupsContainer.querySelector('.new-group-btn');
    
    // 清空现有分组（除了新建分组按钮）
    groupsContainer.innerHTML = '';
    
    // 重新添加预设emoji分组
    DEFAULT_EMOJI_GROUPS.forEach(emoji => {
        const span = document.createElement('span');
        span.className = 'group-emoji';
        span.dataset.emoji = emoji;
        span.textContent = emoji;
        span.style.cssText = `
            cursor: pointer;
            padding: 2px 4px;
        `;
        
        // 添加点击事件
        span.onclick = (e) => {
            e.stopPropagation();
            const emojiSpans = groupsContainer.querySelectorAll('.group-emoji');
            if (selectedEmoji === emoji) {
                span.style.background = 'none';
                selectedEmoji = '';
            } else {
                emojiSpans.forEach(s => s.style.background = 'none');
                span.style.background = isDarkMode ? '#343541' : '#e3f2fd';
                span.style.borderRadius = '6px';
                selectedEmoji = emoji;
            }
        };
        
        groupsContainer.appendChild(span);
    });
    
    // 添加自定义分组
    if (allBookmarks[currentChatId] && allBookmarks[currentChatId].groupOrder) {
        allBookmarks[currentChatId].groupOrder.forEach(groupName => {
            if (groupName && !DEFAULT_EMOJI_GROUPS.includes(groupName)) {
                const span = document.createElement('span');
                span.className = 'group-emoji';
                span.dataset.emoji = groupName;
                span.textContent = groupName;
                span.style.cssText = `
                    cursor: pointer;
                    padding: 2px 4px;
                `;
                
                // 添加点击事件
                span.onclick = (e) => {
                    e.stopPropagation();
                    const emojiSpans = groupsContainer.querySelectorAll('.group-emoji');
                    if (selectedEmoji === groupName) {
                        span.style.background = 'none';
                        selectedEmoji = '';
                    } else {
                        emojiSpans.forEach(s => s.style.background = 'none');
                        span.style.background = isDarkMode ? '#343541' : '#e3f2fd';
                        span.style.borderRadius = '6px';
                        selectedEmoji = groupName;
                    }
                };
                
                groupsContainer.appendChild(span);
            }
        });
    }
    
    // 重新添加新建分组按钮
    if (newGroupBtn) {
        groupsContainer.appendChild(newGroupBtn);
    } else {
        // 如果没有找到原来的按钮，创建一个新的
        const newBtn = document.createElement('button');
        newBtn.className = 'new-group-btn';
                        newBtn.textContent = i18n('addNewGroup');
        newBtn.style.cssText = `
            cursor: pointer;
            padding: 2px 4px;
            background: none;
            border: 1px dashed ${isDarkMode ? '#4a4b4d' : '#ccc'};
            border-radius: 4px;
            color: ${isDarkMode ? '#fff' : '#000'};
        `;
        groupsContainer.appendChild(newBtn);
    }
    
    console.log('✅ 快速操作弹窗分组列表已更新');
}

// 获取国际化文本的辅助函数
function i18n(key, substitutions = []) {
    return chrome.i18n.getMessage(key, substitutions) || key;
}

// 更新UI文本
function updateUIText() {
    const manageBtn = document.querySelector('.manage-btn');
    if (manageBtn) {
        manageBtn.textContent = isManageMode ? i18n('doneMode') : i18n('selectMode');
    }

    // 更新其他UI文本
    const elements = {
        '.new-group-btn': 'newGroup',
        '.default-group': 'defaultGroup',
        '.delete-btn': 'delete',
        '.move-btn': 'move',
        '.export-title': 'exportToGPT',
        '.custom-prompt-title': 'customPrompt',
        '.confirm-export-btn': 'confirmExport',
        '.copy-btn': 'copyToClipboard'
    };

    for (const [selector, messageKey] of Object.entries(elements)) {
        const element = document.querySelector(selector);
        if (element) {
            element.textContent = i18n(messageKey);
        }
    }
}

// 在初始化和UI更新时调用
function initializeUI() {
    // ... existing initialization code ...
    updateUIText();
}

// 更新导出模板中的文本
const exportTemplates = {
    raw: {
        title: i18n('exportRaw'),
        tooltip: i18n('exportRawTooltip'),
        prompt: content => i18n('exportRawPrompt') + content,
        needCustomPrompt: false
    },
    quotes: {
        title: i18n('exportQuotes'),
        tooltip: i18n('exportQuotesTooltip'),
        prompt: content => i18n('exportQuotesPrompt') + content,
        needCustomPrompt: false
    },
    structured: {
        title: i18n('exportStructured'),
        tooltip: i18n('exportStructuredTooltip'),
        prompt: content => i18n('exportStructuredPrompt') + content,
        needCustomPrompt: false
    },
    creative: {
        title: i18n('exportCreative'),
        tooltip: i18n('exportCreativeTooltip'),
        prompt: content => i18n('exportCreativePrompt') + content,
        needCustomPrompt: false
    },
    custom: {
        title: i18n('customPrompt'),
        tooltip: i18n('customPromptTooltip'),
        prompt: (content, customPrompt) => customPrompt + '\n\n' + content,
        needCustomPrompt: true
    }
};

// 更新提示和错误消息
function showMessage(key, substitutions = {}) {
    alert(i18n(key, substitutions));
}

// 在显示选中项数量时使用i18n
function updateSelectedCount(count) {
    const countText = i18n('selectedItems', [count.toString()]);
    // ... update UI with countText ...
}

// 在确认删除时使用i18n
function confirmDelete(count) {
    return confirm(i18n('deleteConfirm', [count.toString()]));
}

// 在复制成功/失败时使用i18n
function handleCopyResult(success) {
    showMessage(success ? 'copySuccess' : 'copyFailed');
}

// ... existing code ...
// 更新错误处理
function handleError(key, err) {
    console.error(`❌ ${i18n(key)}:`, err);
    showMessage(key);
}

// 更新日志
function log(key, ...args) {
    console.log(`✅ ${i18n(key)}`, ...args);
}

// 更新警告
function warn(key, ...args) {
    console.warn(`⚠️ ${i18n(key)}`, ...args);
}

// 更新分组标题
function getGroupTitle(groupName) {
    return groupName || i18n('defaultGroup');
}

// 更新新建分组按钮
const newGroupBtn = document.createElement('button');
newGroupBtn.className = 'new-group-btn';
newGroupBtn.textContent = i18n('newGroup');

// 更新分组输入框
const groupInput = document.createElement('input');
groupInput.type = 'text';
groupInput.placeholder = i18n('enterGroupName');

// 更新取消按钮
const cancelBtn = document.createElement('button');
cancelBtn.className = 'cancel-btn';
cancelBtn.textContent = i18n('cancel');

// 更新确认按钮
const confirmBtn = document.createElement('button');
confirmBtn.className = 'confirm-btn';
confirmBtn.textContent = i18n('confirm');

// ... existing code ...

// 更新按钮文本
function updateButtonText(button, messageKey) {
    if (button) {
        button.textContent = chrome.i18n.getMessage(messageKey);
    }
}

// 更新所有按钮文本
function updateAllButtonsText() {
    // 主要按钮
    updateButtonText(document.querySelector('.organize-export-btn'), 'organizeAndExport');
    updateButtonText(document.querySelector('.save-btn'), 'save');
    updateButtonText(document.querySelector('.add-group-btn'), 'addGroup');
    
    // 批量操作按钮
    updateButtonText(document.querySelector('.batch-delete-btn'), 'batchDelete');
    updateButtonText(document.querySelector('.batch-move-btn'), 'batchMove');
    updateButtonText(document.querySelector('.select-all-btn'), 'selectAll');
    updateButtonText(document.querySelector('.unselect-all-btn'), 'unselectAll');
    
    // 分组操作按钮
    updateButtonText(document.querySelector('.delete-group-btn'), 'deleteGroup');
    updateButtonText(document.querySelector('.edit-group-btn'), 'editGroup');
    updateButtonText(document.querySelector('.collapse-group-btn'), 'collapseGroup');
    updateButtonText(document.querySelector('.expand-group-btn'), 'expandGroup');
}

// 在初始化和UI更新时调用
function initializeUI() {
    // ... existing initialization code ...
    updateAllButtonsText();
}

// 更新确认对话框文本
function showDeleteConfirm(type) {
    const messageKey = type === 'group' ? 'deleteGroupConfirm' : 'deleteBookmarkConfirm';
    return confirm(chrome.i18n.getMessage(messageKey));
}

// 更新按钮创建
function createButton(className, messageKey, clickHandler) {
    const button = document.createElement('button');
    button.className = className;
    button.textContent = chrome.i18n.getMessage(messageKey);
    if (clickHandler) {
        button.addEventListener('click', clickHandler);
    }
    return button;
}

// 在创建UI元素时使用国际化文本
function createBookmarkControls() {
    const controls = document.createElement('div');
    controls.className = 'bookmark-controls';
    
    const organizeExportBtn = createButton('organize-export-btn', 'organizeAndExport', handleOrganizeExport);
    const saveBtn = createButton('save-btn', 'save', handleSave);
    const addGroupBtn = createButton('add-group-btn', 'addGroup', handleAddGroup);
    
    controls.appendChild(organizeExportBtn);
    controls.appendChild(saveBtn);
    controls.appendChild(addGroupBtn);
    
    return controls;
}

// ... existing code ...

// ... existing code ...
// 更新主UI生成代码
function generateMainUI() {
    const container = document.createElement('div');
    container.className = 'bookmark-container';
    
    // 顶部控制栏
    const controls = createBookmarkControls();
    container.appendChild(controls);
    
    // 分组列表
    const groupList = document.createElement('div');
    groupList.className = 'group-list';
    container.appendChild(groupList);
    
    return container;
}

// 更新分组UI生成代码
function generateGroupUI(groupName, bookmarks) {
    const groupContainer = document.createElement('div');
    groupContainer.className = 'group-container';
    
    // 分组标题
    const groupHeader = document.createElement('div');
    groupHeader.className = 'group-header';
    groupHeader.innerHTML = `
        <span class="group-title">${groupName || chrome.i18n.getMessage('defaultGroupName')}</span>
        <div class="group-actions">
            ${createButton('edit-group-btn', 'editGroup').outerHTML}
            ${createButton('delete-group-btn', 'deleteGroup').outerHTML}
            ${createButton('collapse-group-btn', 'collapseGroup').outerHTML}
        </div>
    `;
    
    groupContainer.appendChild(groupHeader);
    
    // 书签列表
    const bookmarkList = document.createElement('div');
    bookmarkList.className = 'bookmark-list';
    if (bookmarks.length === 0) {
        bookmarkList.innerHTML = `<div class="empty-message">${chrome.i18n.getMessage('noBookmarks')}</div>`;
    } else {
        bookmarks.forEach(bookmark => {
            bookmarkList.appendChild(generateBookmarkUI(bookmark));
        });
    }
    
    groupContainer.appendChild(bookmarkList);
    return groupContainer;
}

// 更新批量操作UI
function generateBatchOperationsUI() {
    const container = document.createElement('div');
    container.className = 'batch-operations';
    
    container.appendChild(createButton('select-all-btn', 'selectAll'));
    container.appendChild(createButton('batch-delete-btn', 'batchDelete'));
    container.appendChild(createButton('batch-move-btn', 'batchMove'));
    
    return container;
}

// 更新确认对话框调用
function confirmDelete(type, count) {
    const messageKey = type === 'group' ? 'deleteGroupConfirm' : 'deleteBookmarkConfirm';
    return confirm(chrome.i18n.getMessage(messageKey));
}

// ... existing code ...

// 修改生成主UI的函数
function generateBookmarkUI() {
    const container = document.createElement('div');
    container.className = 'gptburger-container';
    
    // 创建顶部按钮组
    const buttonContainer = document.createElement('div');
    buttonContainer.className = 'button-container';
    
    // 使用国际化文本创建按钮
    const organizeBtn = document.createElement('button');
    organizeBtn.className = 'organize-export-btn';
    organizeBtn.textContent = i18n('organizeAndExport');
    
    const saveBtn = document.createElement('button');
    saveBtn.className = 'save-btn';
    saveBtn.textContent = i18n('save');
    
    const newGroupBtn = document.createElement('button');
    newGroupBtn.className = 'new-group-btn';
    newGroupBtn.textContent = i18n('addGroup');
    
    buttonContainer.appendChild(organizeBtn);
    buttonContainer.appendChild(saveBtn);
    buttonContainer.appendChild(newGroupBtn);
    
    container.appendChild(buttonContainer);
    
    // 添加分组列表容器
    const groupListContainer = document.createElement('div');
    groupListContainer.className = 'group-list-container';
    container.appendChild(groupListContainer);
    
    return container;
}

// 修改创建分组UI的函数
function createGroupElement(groupName) {
    const groupDiv = document.createElement('div');
    groupDiv.className = 'group-item';
    
    const groupNameSpan = document.createElement('span');
    groupNameSpan.textContent = groupName || i18n('defaultGroupName');
    
    const groupActions = document.createElement('div');
    groupActions.className = 'group-actions';
    
    // 创建分组操作按钮
    const editBtn = document.createElement('button');
    editBtn.className = 'edit-group-btn';
    editBtn.textContent = i18n('editGroup');
    
    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'delete-group-btn';
    deleteBtn.textContent = i18n('deleteGroup');
    
    groupActions.appendChild(editBtn);
    groupActions.appendChild(deleteBtn);
    
    groupDiv.appendChild(groupNameSpan);
    groupDiv.appendChild(groupActions);
    
    return groupDiv;
}

// 修改确认对话框
function showConfirmDialog(type) {
    const message = type === 'delete' ? i18n('deleteBookmarkConfirm') : i18n('deleteGroupConfirm');
    return confirm(message);
}

// ... 其他现有代码 ...

// 添加调试函数
function debugI18n() {
    console.log('Current language:', chrome.i18n.getUILanguage());
    console.log('Test i18n messages:');
    [
        'organizeAndExport',
        'save',
        'addGroup',
        'defaultGroupName',
        'editGroup',
        'deleteGroup'
    ].forEach(key => {
        console.log(`${key}:`, chrome.i18n.getMessage(key));
    });
}

// 在初始化时调用调试函数
document.addEventListener('DOMContentLoaded', () => {
    debugI18n();
    updateMainButtons();
});

// 修改 i18n 函数添加调试信息
function i18n(key, substitutions = []) {
    const message = chrome.i18n.getMessage(key, substitutions);
    if (!message) {
        console.warn(`Missing i18n message for key: ${key}`);
        return key;
    }
    return message;
}

// ... 其他现有代码 ...

// 高亮显示新创建的书签
function highlightNewBookmark(bookmarkId) {
    setTimeout(() => {
        const bookmarkElement = document.querySelector(`[data-id="${bookmarkId}"]`);
        if (bookmarkElement) {
            // 检测当前主题
            const isDarkMode = document.documentElement.classList.contains('dark');
            const highlightColor = isDarkMode ? '#2c3e50' : '#e3f2fd';
            
            // 添加高亮效果
            bookmarkElement.style.transition = 'background-color 0.3s ease';
            bookmarkElement.style.backgroundColor = highlightColor;
            
            // 滚动到书签位置
            const bookmarkList = document.getElementById('gpt-bookmark-list');
            if (bookmarkList) {
                const bookmarkContent = bookmarkList.querySelector('.bookmark-content');
                if (bookmarkContent) {
                    // 计算书签在容器中的位置
                    const containerRect = bookmarkContent.getBoundingClientRect();
                    const elementRect = bookmarkElement.getBoundingClientRect();
                    const scrollTop = bookmarkContent.scrollTop;
                    const targetScrollTop = scrollTop + (elementRect.top - containerRect.top) - containerRect.height / 2;
                    
                    bookmarkContent.scrollTo({
                        top: Math.max(0, targetScrollTop),
                        behavior: 'smooth'
                    });
                }
            }
            
            // 2秒后移除高亮
            setTimeout(() => {
                bookmarkElement.style.backgroundColor = '';
                setTimeout(() => {
                    bookmarkElement.style.transition = '';
                }, 300);
            }, 2000);
            
            console.log('✨ 高亮显示新书签:', bookmarkId);
        }
    }, 200); // 给渲染更多时间
}

// 展开书签边栏
function showBookmarkSidebar() {
    const toggleBtn = document.getElementById('gpt-bookmark-toggle');
    const list = document.getElementById('gpt-bookmark-list');
    
    if (toggleBtn && list) {
        if (list.classList.contains('collapsed')) {
            list.classList.remove('collapsed');
            toggleBtn.innerHTML = "📖";
            toggleBtn.title = "收起书签";
            console.log("�� 自动展开书签列表（创建书签）");
        }
        
        // 设置保持展开状态，3秒后自动检查是否需要收起
        list.setAttribute('data-keep-open', 'true');
        console.log("🔒 设置保持展开状态，3秒后自动检查");
        
        setTimeout(() => {
            console.log("⏰ 3秒后检查是否需要收起书签栏");
            list.removeAttribute('data-keep-open');
            
            // 检查是否仍在悬停状态
            setTimeout(() => {
                if (!isHoveringButton && !isHoveringList && !list.classList.contains('collapsed')) {
                    list.classList.add('collapsed');
                    toggleBtn.innerHTML = "📑";
                    toggleBtn.title = "展开书签";
                    console.log("📂 自动收起书签列表（3秒后）");
                }
            }, 100);
        }, 3000);
        
        return true;
    }
    return false;
}

// 🆕 分析选中内容的容器信息
function analyzeSelectionContainer(selection, article, selectedText) {
    console.log('🔍 [定位分析] 开始分析选中内容的容器信息');
    
    if (!selection || selection.rangeCount === 0) {
        console.warn('❌ [定位分析] 没有有效的选择范围');
        return null;
    }
    
    const range = selection.getRangeAt(0);
    const startContainer = range.startContainer;
    const endContainer = range.endContainer;
    
    console.log('📍 [定位分析] 选择范围信息:', {
        startContainer: startContainer.nodeName,
        endContainer: endContainer.nodeName,
        startOffset: range.startOffset,
        endOffset: range.endOffset
    });
    
    // 检测容器类型
    const containerType = detectContainerType(range);
    console.log('🏷️ [定位分析] 检测到容器类型:', containerType);
    
    // 获取直接容器元素
    const directContainer = findDirectContainer(range);
    console.log('📦 [定位分析] 直接容器:', directContainer ? {
        tagName: directContainer.tagName,
        className: directContainer.className,
        offsetTop: directContainer.offsetTop
    } : '未找到');
    
    // 计算相对于article的偏移
    const relativeOffset = directContainer ? 
        directContainer.offsetTop - article.offsetTop : 0;
    
    const containerInfo = {
        type: containerType,
        container: directContainer ? {
            tagName: directContainer.tagName,
            className: directContainer.className,
            offsetTop: directContainer.offsetTop,
            relativeToArticle: relativeOffset,
            // 🆕 保存用户实际选中的文本，而不是容器的全部文本
            selectedText: selectedText.substring(0, 100).trim(), // 用户实际选中的文本
            containerText: directContainer.textContent ? directContainer.textContent.substring(0, 100).trim() : '', // 容器的文本（备用）
            innerHTML: directContainer.innerHTML ? directContainer.innerHTML.substring(0, 200) : '', // 前200个字符的HTML
            attributes: {
                id: directContainer.id || null,
                role: directContainer.getAttribute('role') || null,
                'data-testid': directContainer.getAttribute('data-testid') || null
            },
            // 🆕 表格单元格专用信息
            tableInfo: getTableCellInfo(directContainer),
            // 🆕 添加更多辅助信息
            outerHTML: directContainer.outerHTML ? directContainer.outerHTML.substring(0, 300) : '', // 外层HTML用于更精确的匹配
            textLength: directContainer.textContent ? directContainer.textContent.length : 0, // 文本总长度
            childElementCount: directContainer.childElementCount || 0 // 子元素数量
        } : null,
        // 兜底：保存原有的简单偏移
        fallbackOffset: article.offsetTop,
        timestamp: Date.now()
    };
    
    console.log('✅ [定位分析] 分析完成:', containerInfo);
    return containerInfo;
}

// 🆕 检测容器类型
function detectContainerType(range) {
    let element = range.commonAncestorContainer;
    
    // 如果是文本节点，获取其父元素
    if (element.nodeType === Node.TEXT_NODE) {
        element = element.parentElement;
    }
    
    console.log('🔍 [容器检测] 开始从元素检测:', element.tagName);
    
    // 向上查找最近的有意义容器
    let currentElement = element;
    while (currentElement && !currentElement.matches('article')) {
        const tagName = currentElement.tagName.toLowerCase();
        const className = currentElement.className || '';
        
        console.log(`🔍 [容器检测] 检查元素: ${tagName}.${className}`);
        
        // 代码块检测
        if (tagName === 'pre' || tagName === 'code' || 
            className.includes('code') || className.includes('highlight')) {
            console.log('💻 [容器检测] 识别为代码块');
            return 'code';
        }
        
        // 表格检测
        if (tagName === 'table' || tagName === 'td' || tagName === 'th' || tagName === 'tr') {
            console.log('📊 [容器检测] 识别为表格');
            return 'table';
        }
        
        // 标题检测
        if (tagName.match(/^h[1-6]$/)) {
            console.log('📝 [容器检测] 识别为标题');
            return 'heading';
        }
        
        // 引用块检测
        if (tagName === 'blockquote') {
            console.log('💬 [容器检测] 识别为引用块');
            return 'quote';
        }
        
        currentElement = currentElement.parentElement;
    }
    
    console.log('📄 [容器检测] 识别为普通文本');
    return 'text';
}

// 🆕 查找直接容器元素
function findDirectContainer(range) {
    let element = range.commonAncestorContainer;
    
    if (element.nodeType === Node.TEXT_NODE) {
        element = element.parentElement;
    }
    
    console.log('🔍 [直接容器] 开始查找从:', element.tagName);
    
    // 🆕 特殊处理：先查找表格单元格
    let tableCell = element;
    while (tableCell && !tableCell.matches('article')) {
        if (tableCell.tagName === 'TD' || tableCell.tagName === 'TH') {
            console.log(`✅ [直接容器] 找到表格单元格: ${tableCell.tagName}`);
            return tableCell;
        }
        tableCell = tableCell.parentElement;
    }
    
    // 查找最近的块级容器
    while (element && !element.matches('article')) {
        const tagName = element.tagName.toLowerCase();
        const className = element.className || '';
        
        console.log(`🔍 [直接容器] 检查: ${tagName}.${className}`);
        
        // 检查是否是我们关心的容器类型
        if (tagName === 'pre' || tagName === 'blockquote' ||
            tagName.match(/^h[1-6]$/) || 
            (tagName === 'div' && (className.includes('code') || className.includes('table'))) ||
            (tagName === 'p' && element.textContent.trim().length > 0)) {
            
            console.log(`✅ [直接容器] 找到目标容器: ${tagName}.${className}`);
            return element;
        }
        
        // 🆕 如果没找到更精确的容器，table作为最后备选
        if (tagName === 'table') {
            console.log(`⚠️ [直接容器] 备选容器: ${tagName}.${className} (未找到单元格)`);
            return element;
        }
        
        element = element.parentElement;
    }
    
    console.log('❌ [直接容器] 未找到合适的容器');
    return null;
}

// 🆕 获取表格单元格的位置信息
function getTableCellInfo(element) {
    if (!element || (element.tagName !== 'TD' && element.tagName !== 'TH')) {
        return null;
    }
    
    console.log('📊 [表格分析] 开始分析单元格位置');
    
    try {
        const row = element.parentElement; // TR
        const table = row.closest('table');
        
        if (!table || !row) {
            console.warn('❌ [表格分析] 无法找到表格或行元素');
            return null;
        }
        
        // 计算行索引
        const allRows = Array.from(table.querySelectorAll('tr'));
        const rowIndex = allRows.indexOf(row);
        
        // 计算列索引
        const cellsInRow = Array.from(row.querySelectorAll('td, th'));
        const colIndex = cellsInRow.indexOf(element);
        
        const tableInfo = {
            rowIndex,
            colIndex,
            rowCount: allRows.length,
            colCount: cellsInRow.length,
            cellText: element.textContent.trim(),
            isHeader: element.tagName === 'TH'
        };
        
        console.log('📊 [表格分析] 单元格位置信息:', tableInfo);
        return tableInfo;
        
    } catch (error) {
        console.error('❌ [表格分析] 分析单元格位置时出错:', error);
        return null;
    }
}

// And at the very end of the file, let's log to be sure the whole script was parsed
console.log("🍔 GPT Burger content script parsed successfully.");